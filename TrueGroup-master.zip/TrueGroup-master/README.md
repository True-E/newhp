## Install
Execute in the project root directory: 
```
npm install
```


## Build
Execute in the project root directory: 
```
npm run build
```
And the build product will be in the ``dist`` directory
