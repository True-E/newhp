module.exports = {
  plugins: [
    [
      "autoprefixer"
    ],
  ],
};