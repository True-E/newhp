function gr(t, e) {
  for (var n = 0; n < e.length; n++) {
    var r = e[n];
    r.enumerable = r.enumerable || !1,
      r.configurable = !0,
      "value" in r && (r.writable = !0),
      Object.defineProperty(t, r.key, r)
  }
}

function initCursor(t, opts) {
  t.width = t.clientWidth / 2,
    t.height = t.clientHeight / 2;
  var e = {
    SIM_RESOLUTION: 128,
    DYE_RESOLUTION: 512,
    DENSITY_DISSIPATION: .97,
    VELOCITY_DISSIPATION: .98,
    PRESSURE_DISSIPATION: .8,
    PRESSURE_ITERATIONS: 10,
    CURL: 5,
    SPLAT_RADIUS: .6,
    SHADING: true,
    COLORFUL: true,
    BACK_COLOR: opts && opts.BACK_COLOR || {
      r: 0,
      g: 0,
      b: 0,
      a: 1
    },
    TRANSPARENT: false,
    BLOOM: false,
    BLOOM_ITERATIONS: 8,
    BLOOM_RESOLUTION: 256,
    BLOOM_INTENSITY: .8,
    BLOOM_THRESHOLD: .6,
    BLOOM_SOFT_KNEE: .7
  };
  function n() {
    this.id = -1,
      this.x = 0,
      this.y = 0,
      this.dx = 0,
      this.dy = 0,
      this.down = !1,
      this.moved = !1,
      this.color = [30, 0, 300]
  }
  var i = []
    , o = []
    , s = [];
  i.push(new n);
  var a = function (t) {
    var e, n, r = {
      alpha: true,
      depth: false,
      stencil: false,
      antialias: false,
      preserveDrawingBuffer: false
    }, i = t.getContext("webgl2", r), o = !!i;
    o || (i = t.getContext("webgl", r) || t.getContext("experimental-webgl", r));
    o ? (i.getExtension("EXT_color_buffer_float"),
      n = i.getExtension("OES_texture_float_linear")) : (e = i.getExtension("OES_texture_half_float"),
        n = i.getExtension("OES_texture_half_float_linear"));
    i.clearColor(0, 0, 0, 1);
    var s, a, c, l = o ? i.HALF_FLOAT : e.HALF_FLOAT_OES;
    o ? (s = u(i, i.RGBA16F, i.RGBA, l),
      a = u(i, i.RG16F, i.RG, l),
      c = u(i, i.R16F, i.RED, l)) : (s = u(i, i.RGBA, i.RGBA, l),
        a = u(i, i.RGBA, i.RGBA, l),
        c = u(i, i.RGBA, i.RGBA, l));
    return {
      gl: i,
      ext: {
        formatRGBA: s,
        formatRG: a,
        formatR: c,
        halfFloatTexType: l,
        supportLinearFiltering: n
      }
    }
  }(t)
    , gl = a.gl
    , l = a.ext;
  function u(t, e, n, r) {
    if (!function (t, e, n, r) {
      var i = t.createTexture();
      t.bindTexture(t.TEXTURE_2D, i),
        t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.NEAREST),
        t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.NEAREST),
        t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_S, t.CLAMP_TO_EDGE),
        t.texParameteri(t.TEXTURE_2D, t.TEXTURE_WRAP_T, t.CLAMP_TO_EDGE),
        t.texImage2D(t.TEXTURE_2D, 0, e, 4, 4, 0, n, r, null);
      var o = t.createFramebuffer();
      if (t.bindFramebuffer(t.FRAMEBUFFER, o),
        t.framebufferTexture2D(t.FRAMEBUFFER, t.COLOR_ATTACHMENT0, t.TEXTURE_2D, i, 0),
        t.checkFramebufferStatus(t.FRAMEBUFFER) !== t.FRAMEBUFFER_COMPLETE)
        return !1;
      return !0
    }(t, e, n, r))
      switch (e) {
        case t.R16F:
          return u(t, t.RG16F, t.RG, r);
        case t.RG16F:
          return u(t, t.RGBA16F, t.RGBA, r);
        default:
          return null
      }
    return {
      internalFormat: e,
      format: n
    }
  }
  // r.a.viewport.mobiledevice && (e.SHADING = !1),
  //   l.supportLinearFiltering || (e.SHADING = !1,
  //     e.BLOOM = !1),
  //   function () {
  //     if (!ve.b)
  //       return;
  //     var t = ve.b.addFolder("splash bg");
  //     t.add(e, "DENSITY_DISSIPATION", 0, 4),
  //       t.add(e, "VELOCITY_DISSIPATION", 0, 1),
  //       t.add(e, "PRESSURE_DISSIPATION", 0, 1),
  //       t.add(e, "CURL", 0, 50).name("vorticity").step(1),
  //       t.add(e, "SPLAT_RADIUS", .01, 1),
  //       t.add(e, "SHADING"),
  //       t.add(e, "COLORFUL"),
  //       t.add(e, "BLOOM"),
  //       t.add(e, "BLOOM_INTENSITY", .1, 2).name("intensity"),
  //       t.add(e, "BLOOM_THRESHOLD", 0, 1).name("threshold")
  //   }();
  var h = function () {
    function t(e, n) {
      if (function (t, e) {
        if (!(t instanceof e))
          throw new TypeError("Cannot call a class as a function")
      }(this, t),
        this.uniforms = {},
        this.program = gl.createProgram(),
        gl.attachShader(this.program, e),
        gl.attachShader(this.program, n),
        gl.linkProgram(this.program),
        !gl.getProgramParameter(this.program, gl.LINK_STATUS))
        throw gl.getProgramInfoLog(this.program);
      for (var r = gl.getProgramParameter(this.program, gl.ACTIVE_UNIFORMS), i = 0; i < r; i++) {
        var o = gl.getActiveUniform(this.program, i).name;
        this.uniforms[o] = gl.getUniformLocation(this.program, o)
      }
    }
    var e, n, r;
    return e = t,
      (n = [{
        key: "bind",
        value: function () {
          gl.useProgram(this.program)
        }
      }]) && gr(e.prototype, n),
      r && gr(e, r),
      t
  }();
  function compileShader(t, e) {
    var n = gl.createShader(t);
    if (gl.shaderSource(n, e),
      gl.compileShader(n),
      !gl.getShaderParameter(n, gl.COMPILE_STATUS))
      throw gl.getShaderInfoLog(n);
    return n
  }
  var d, p, m, v, g, y, _, b, x, w;
  var baseVertexShader = compileShader(gl.VERTEX_SHADER, "\n    precision highp float;\n    attribute vec2 aPosition;\n    varying vec2 vUv;\n    varying vec2 vL;\n    varying vec2 vR;\n    varying vec2 vT;\n    varying vec2 vB;\n    uniform vec2 texelSize;\n    void main () {\n        vUv = aPosition * 0.5 + 0.5;\n        vL = vUv - vec2(texelSize.x, 0.0);\n        vR = vUv + vec2(texelSize.x, 0.0);\n        vT = vUv + vec2(0.0, texelSize.y);\n        vB = vUv - vec2(0.0, texelSize.y);\n        gl_Position = vec4(aPosition, 0.0, 1.0);\n    }\n");
  var shader1 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    precision mediump sampler2D;\n    varying highp vec2 vUv;\n    uniform sampler2D uTexture;\n    uniform float value;\n    void main () {\n        gl_FragColor = value * texture2D(uTexture, vUv);\n    }\n");
  var shader2 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    uniform vec4 color;\n    void main () {\n        gl_FragColor = color;\n    }\n");
  var shader3 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    uniform sampler2D uTexture;\n    uniform float aspectRatio;\n    #define SCALE 25.0\n    void main () {\n        vec2 uv = floor(vUv * SCALE * vec2(aspectRatio, 1.0));\n        float v = mod(uv.x + uv.y, 2.0);\n        v = v * 0.1 + 0.8;\n        gl_FragColor = vec4(vec3(v), 1.0);\n    }\n");
  var shader4 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    uniform sampler2D uTexture;\n    void main () {\n        vec3 C = texture2D(uTexture, vUv).rgb;\n        float a = max(C.r, max(C.g, C.b));\n        gl_FragColor = vec4(C, a);\n    }\n");
  var shader5 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    uniform sampler2D uTexture;\n    uniform sampler2D uBloom;\n    uniform sampler2D uDithering;\n    uniform vec2 ditherScale;\n    void main () {\n        vec3 C = texture2D(uTexture, vUv).rgb;\n        vec3 bloom = texture2D(uBloom, vUv).rgb;\n        vec3 noise = texture2D(uDithering, vUv * ditherScale).rgb;\n        noise = noise * 2.0 - 1.0;\n        bloom += noise / 800.0;\n        bloom = pow(bloom.rgb, vec3(1.0 / 2.2));\n        C += bloom;\n        float a = max(C.r, max(C.g, C.b));\n        gl_FragColor = vec4(C, a);\n    }\n");
  var shader6 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    varying vec2 vL;\n    varying vec2 vR;\n    varying vec2 vT;\n    varying vec2 vB;\n    uniform sampler2D uTexture;\n    uniform vec2 texelSize;\n    void main () {\n        vec3 L = texture2D(uTexture, vL).rgb;\n        vec3 R = texture2D(uTexture, vR).rgb;\n        vec3 T = texture2D(uTexture, vT).rgb;\n        vec3 B = texture2D(uTexture, vB).rgb;\n        vec3 C = texture2D(uTexture, vUv).rgb;\n        float dx = length(R) - length(L);\n        float dy = length(T) - length(B);\n        vec3 n = normalize(vec3(dx, dy, length(texelSize)));\n        vec3 l = vec3(0.0, 0.0, 1.0);\n        float diffuse = clamp(dot(n, l) + 0.7, 0.7, 1.0);\n        C.rgb *= diffuse;\n        float a = max(C.r, max(C.g, C.b));\n        gl_FragColor = vec4(C, a);\n    }\n");
  var shader7 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    varying vec2 vL;\n    varying vec2 vR;\n    varying vec2 vT;\n    varying vec2 vB;\n    uniform sampler2D uTexture;\n    uniform sampler2D uBloom;\n    uniform sampler2D uDithering;\n    uniform vec2 ditherScale;\n    uniform vec2 texelSize;\n    void main () {\n        vec3 L = texture2D(uTexture, vL).rgb;\n        vec3 R = texture2D(uTexture, vR).rgb;\n        vec3 T = texture2D(uTexture, vT).rgb;\n        vec3 B = texture2D(uTexture, vB).rgb;\n        vec3 C = texture2D(uTexture, vUv).rgb;\n        float dx = length(R) - length(L);\n        float dy = length(T) - length(B);\n        vec3 n = normalize(vec3(dx, dy, length(texelSize)));\n        vec3 l = vec3(0.0, 0.0, 1.0);\n        float diffuse = clamp(dot(n, l) + 0.7, 0.7, 1.0);\n        C *= diffuse;\n        vec3 bloom = texture2D(uBloom, vUv).rgb;\n        vec3 noise = texture2D(uDithering, vUv * ditherScale).rgb;\n        noise = noise * 2.0 - 1.0;\n        bloom += noise / 800.0;\n        bloom = pow(bloom.rgb, vec3(1.0 / 2.2));\n        C += bloom;\n        float a = max(C.r, max(C.g, C.b));\n        gl_FragColor = vec4(C, a);\n    }\n");
  var shader8 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    precision mediump sampler2D;\n    varying vec2 vUv;\n    uniform sampler2D uTexture;\n    uniform vec3 curve;\n    uniform float threshold;\n    void main () {\n        vec3 c = texture2D(uTexture, vUv).rgb;\n        float br = max(c.r, max(c.g, c.b));\n        float rq = clamp(br - curve.x, 0.0, curve.y);\n        rq = curve.z * rq * rq;\n        c *= max(rq, br - threshold) / max(br, 0.0001);\n        gl_FragColor = vec4(c, 0.0);\n    }\n");
  var shader9 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    precision mediump sampler2D;\n    varying vec2 vL;\n    varying vec2 vR;\n    varying vec2 vT;\n    varying vec2 vB;\n    uniform sampler2D uTexture;\n    void main () {\n        vec4 sum = vec4(0.0);\n        sum += texture2D(uTexture, vL);\n        sum += texture2D(uTexture, vR);\n        sum += texture2D(uTexture, vT);\n        sum += texture2D(uTexture, vB);\n        sum *= 0.25;\n        gl_FragColor = sum;\n    }\n");
  var shader10 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    precision mediump sampler2D;\n    varying vec2 vL;\n    varying vec2 vR;\n    varying vec2 vT;\n    varying vec2 vB;\n    uniform sampler2D uTexture;\n    uniform float intensity;\n    void main () {\n        vec4 sum = vec4(0.0);\n        sum += texture2D(uTexture, vL);\n        sum += texture2D(uTexture, vR);\n        sum += texture2D(uTexture, vT);\n        sum += texture2D(uTexture, vB);\n        sum *= 0.25;\n        gl_FragColor = sum * intensity;\n    }\n");
  var shader11 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    uniform sampler2D uTarget;\n    uniform float aspectRatio;\n    uniform vec3 color;\n    uniform vec2 point;\n    uniform float radius;\n    void main () {\n        vec2 p = vUv - point.xy;\n        p.x *= aspectRatio;\n        vec3 splat = exp(-dot(p, p) / radius) * color;\n        vec3 base = texture2D(uTarget, vUv).xyz;\n        gl_FragColor = vec4(base + splat, 1.0);\n    }\n");
  var shader12 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    uniform sampler2D uVelocity;\n    uniform sampler2D uSource;\n    uniform vec2 texelSize;\n    uniform vec2 dyeTexelSize;\n    uniform float dt;\n    uniform float dissipation;\n    vec4 bilerp (sampler2D sam, vec2 uv, vec2 tsize) {\n        vec2 st = uv / tsize - 0.5;\n        vec2 iuv = floor(st);\n        vec2 fuv = fract(st);\n        vec4 a = texture2D(sam, (iuv + vec2(0.5, 0.5)) * tsize);\n        vec4 b = texture2D(sam, (iuv + vec2(1.5, 0.5)) * tsize);\n        vec4 c = texture2D(sam, (iuv + vec2(0.5, 1.5)) * tsize);\n        vec4 d = texture2D(sam, (iuv + vec2(1.5, 1.5)) * tsize);\n        return mix(mix(a, b, fuv.x), mix(c, d, fuv.x), fuv.y);\n    }\n    void main () {\n        vec2 coord = vUv - dt * bilerp(uVelocity, vUv, texelSize).xy * texelSize;\n        gl_FragColor = dissipation * bilerp(uSource, coord, dyeTexelSize);\n        gl_FragColor.a = 1.0;\n    }\n");
  var shader13 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    uniform sampler2D uVelocity;\n    uniform sampler2D uSource;\n    uniform vec2 texelSize;\n    uniform float dt;\n    uniform float dissipation;\n    void main () {\n        vec2 coord = vUv - dt * texture2D(uVelocity, vUv).xy * texelSize;\n        gl_FragColor = dissipation * texture2D(uSource, coord);\n        gl_FragColor.a = 1.0;\n    }\n");
  var shader14 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    precision mediump sampler2D;\n    varying highp vec2 vUv;\n    varying highp vec2 vL;\n    varying highp vec2 vR;\n    varying highp vec2 vT;\n    varying highp vec2 vB;\n    uniform sampler2D uVelocity;\n    void main () {\n        float L = texture2D(uVelocity, vL).x;\n        float R = texture2D(uVelocity, vR).x;\n        float T = texture2D(uVelocity, vT).y;\n        float B = texture2D(uVelocity, vB).y;\n        vec2 C = texture2D(uVelocity, vUv).xy;\n        if (vL.x < 0.0) { L = -C.x; }\n        if (vR.x > 1.0) { R = -C.x; }\n        if (vT.y > 1.0) { T = -C.y; }\n        if (vB.y < 0.0) { B = -C.y; }\n        float div = 0.5 * (R - L + T - B);\n        gl_FragColor = vec4(div, 0.0, 0.0, 1.0);\n    }\n");
  var shader15 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    precision mediump sampler2D;\n    varying highp vec2 vUv;\n    varying highp vec2 vL;\n    varying highp vec2 vR;\n    varying highp vec2 vT;\n    varying highp vec2 vB;\n    uniform sampler2D uVelocity;\n    void main () {\n        float L = texture2D(uVelocity, vL).y;\n        float R = texture2D(uVelocity, vR).y;\n        float T = texture2D(uVelocity, vT).x;\n        float B = texture2D(uVelocity, vB).x;\n        float vorticity = R - L - T + B;\n        gl_FragColor = vec4(0.5 * vorticity, 0.0, 0.0, 1.0);\n    }\n");
  var shader16 = compileShader(gl.FRAGMENT_SHADER, "\n    precision highp float;\n    precision highp sampler2D;\n    varying vec2 vUv;\n    varying vec2 vL;\n    varying vec2 vR;\n    varying vec2 vT;\n    varying vec2 vB;\n    uniform sampler2D uVelocity;\n    uniform sampler2D uCurl;\n    uniform float curl;\n    uniform float dt;\n    void main () {\n        float L = texture2D(uCurl, vL).x;\n        float R = texture2D(uCurl, vR).x;\n        float T = texture2D(uCurl, vT).x;\n        float B = texture2D(uCurl, vB).x;\n        float C = texture2D(uCurl, vUv).x;\n        vec2 force = 0.5 * vec2(abs(T) - abs(B), abs(R) - abs(L));\n        force /= length(force) + 0.0001;\n        force *= curl * C;\n        force.y *= -1.0;\n        vec2 vel = texture2D(uVelocity, vUv).xy;\n        gl_FragColor = vec4(vel + force * dt, 0.0, 1.0);\n    }\n");
  var shader17 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    precision mediump sampler2D;\n    varying highp vec2 vUv;\n    varying highp vec2 vL;\n    varying highp vec2 vR;\n    varying highp vec2 vT;\n    varying highp vec2 vB;\n    uniform sampler2D uPressure;\n    uniform sampler2D uDivergence;\n    vec2 boundary (vec2 uv) {\n        return uv;\n        // uncomment if you use wrap or repeat texture mode\n        // uv = min(max(uv, 0.0), 1.0);\n        // return uv;\n    }\n    void main () {\n        float L = texture2D(uPressure, boundary(vL)).x;\n        float R = texture2D(uPressure, boundary(vR)).x;\n        float T = texture2D(uPressure, boundary(vT)).x;\n        float B = texture2D(uPressure, boundary(vB)).x;\n        float C = texture2D(uPressure, vUv).x;\n        float divergence = texture2D(uDivergence, vUv).x;\n        float pressure = (L + R + B + T - divergence) * 0.25;\n        gl_FragColor = vec4(pressure, 0.0, 0.0, 1.0);\n    }\n");
  var shader18 = compileShader(gl.FRAGMENT_SHADER, "\n    precision mediump float;\n    precision mediump sampler2D;\n    varying highp vec2 vUv;\n    varying highp vec2 vL;\n    varying highp vec2 vR;\n    varying highp vec2 vT;\n    varying highp vec2 vB;\n    uniform sampler2D uPressure;\n    uniform sampler2D uVelocity;\n    vec2 boundary (vec2 uv) {\n        return uv;\n        // uv = min(max(uv, 0.0), 1.0);\n        // return uv;\n    }\n    void main () {\n        float L = texture2D(uPressure, boundary(vL)).x;\n        float R = texture2D(uPressure, boundary(vR)).x;\n        float T = texture2D(uPressure, boundary(vT)).x;\n        float B = texture2D(uPressure, boundary(vB)).x;\n        vec2 velocity = texture2D(uVelocity, vUv).xy;\n        velocity.xy -= vec2(R - L, T - B);\n        gl_FragColor = vec4(velocity, 0.0, 1.0);\n    }\n");

  var U = (gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer()),
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, -1, 1, 1, 1, 1, -1]), gl.STATIC_DRAW),
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, gl.createBuffer()),
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 0, 2, 3]), gl.STATIC_DRAW),
    gl.vertexAttribPointer(0, 2, gl.FLOAT, !1, 0, 0),
    gl.enableVertexAttribArray(0),
    function (t) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, t),
        gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0)
    }
  ), G = function (t) {
    var e = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, e),
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR),
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR),
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT),
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT),
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, 1, 1, 0, gl.RGB, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255]));
    var n = {
      texture: e,
      width: 1,
      height: 1,
      attach: function (t) {
        return gl.activeTexture(gl.TEXTURE0 + t),
          gl.bindTexture(gl.TEXTURE_2D, e),
          t
      }
    }
      , r = new Image;
    return r.crossOrigin = "anonymous",
      r.onload = function () {
        n.width = r.width,
          n.height = r.height,
          gl.bindTexture(gl.TEXTURE_2D, e),
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, r)
      }
      ,
      r.src = t,
      n
  }("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAA3bElEQVR4nBWXh1uNDx+HT4SMlhClZEQUqSirVEoDoVIqmVFKoVBWKqKIpKGFjAaSmawIRaUhq2j/KrQUJUrc73n/gHOdcz3P93zu+xZ8Gu6AR6U7SfHvGD3YnM87fZnTtYlzx6UwFbtCv48+JK8VsPvufN7UuBJqM5HlygMYtXE2hslP+c9sDD8+a3LO5R9LU4+w5/gj0gtUaHdowv2CK5nPeikPv8CY9HSWen5lyzRDYu1Os3KRKtNef6fx4myq/A5gmefCWdkPvGo0YvVmDSInXMVAczd/9hVy7sYCHJWcyAy6Tes3byIfKSESfp6L9hJ0nE3Da2Yhs51/4LtiJbUnSzl3fyjePo2YFT6jSXIe92qF339qMTufHuW6axdLrVyIb3vC6hwtBINnVnAiI5gfFqLsK4pjg2Edz28qMGX6A+4tX0Kt7wy6IjoYN8wOKa9bbBGvgCNLSfoYw655zawMu4bqLk8eKEVxTH0+MwetZ/XWfST9TGWi5Bxsv4rgM3oXWnNX8bJzJgfPSyIQceH+qXyCvBehIJFE0pQs5lhO4l9kJ15HYhAxXcq9qhZWPDxJYZgtMz+rUrUpBNWBIoyY/ZKy5ctxU93CoYb/KC7UwVx8A+F/vGm7NIppC6azQnQLAqdYrkxwROuOInar2/ir4Ylh6SfyU5SRmRyDv8RBssPlERh3/8Z223wmTbnJ9ZR1iK1W5c/7UEJH/GHYY3f8yGe1aTjRxXIYab+gMtaLGbk9PGsbzgCBLxFZH8l715eN1i/pba9jjMlQYqIUeXUzm4WTI+k+VEuE5WMuFx+jc10Xhn5naXn5Hx/SbrKteRA5m5txKg/n1B9bhl4RwUQsl8C2AOrPSjBG5h6+85W4bdVAv7hLHC8s5fLO78xNn4b1wXuou/WiODaUjOtiDNidxOYpj7j+upXCg8cJ7jSm/Mxbns0/xIH904j+k4qKrDQbds6hrjGXGTfMaF17AcHFMQ8p/m8ntUeGoy3axpGm5yzbs5IPsQZs3VLGvKQJpE1KoPDzZ444BXPngRrrLa6iPHU9h1YbUj7Kjnk3JiMRuBiz6kSqH/2m/x5rPs96y5HShUg6T+bNmRHIDlzMhvocJk6cwPmFK5mp4IP4jCAWZYzim+F2JoyZx+v190mdu5Yfd2qZssqVSzvm4v63m0WTPfmZZca6qgPskB3Gg544/gnsqTZW4Ozz/Xw9Vo7jkmXkfJnP0KxX/Bw+gfEfb+C0opsRL4bTkPiQIYIw3pnbc+L4Oy4X7GZrQDOjjCUQ7Dm/nIgVEUhll+AaMZvcWRc5M24AY7/f4fH8ANr7SKIevJbl1+YxUGERP38N5uyBU5heekTr1wJS3Ntw1znBzfh7+A3w4/E6DTxfbWOaYhAuLR3oGTtxL9UfK59yau9tZcfx/jzjHfZvjYhy0OTW4UI+navgwPO/2H5I4cn+YWxUm4ZuyUU+5JQwRDSS/1IGEX3gFi9N17FwtS6DIo5yNPkNMu8Xsvd7DvNlJqMS20XM6jVYaJ9jx9a+zArfzaWpy1k4eiPbN9dwo9UA6we96Nn1p1P7BuP7r+XBe3UEc7w/g6wL5j+VubPxEK33P+FgtQvD/EYE5RpccEzlc04Xsj5ZPNfdx/YB7xl9spG3C7Sxvj8Wmb3n6fonzfiJLrw3KCcseQDLh97kqk0cOUGSnMt6wN7fFxGVnc4x7WvcWHoKebdv+Effo2PEefR+OLGzrwX9to1H46QPJ34FMUK+nbjFi3kWPBp7JzsOteQip6CFyoyftNx6ytuvdTioiZK6wpPs2Wm4e0XRXSHD+/6BHLriQaZJA1//zSDyZg6vq4agHhjH7/z9PIl+Rp/xHgQ2jKVgUyiOjwoR9NMQ4aN+Cl6f/iEvbcLUayMJOLCJyiHL8Dl5Ghf1t4RbbMOhZTi+JSnUbbNi1idXjk8YwMMhh/Gx3IHGm5/EPZ/LqtAi5nxeTc+vFobGjKPZfTYTBhfzaaoNrAadPH1MKhX4PGA/RVmTUdv1G5makzw068cZ9dvU2ETTNmQBS2M/suvaY/7W7URTI5CM01Xov5fl2pZk9gdvIV5iEto+5xl7ro1FTk6Eps9hyMQaLn97gEKwIgsevmHgoGPc8Ulm5dJvHJ2hjKKEBecMNNm8LZGqpA4s/i4gPtwfgWqeAlmXX3A00J4i8/tcVj2LTEMHPVvHc/1iJot+9+H1HSPGS9ehf3Yy11bEEfcERFPScaqrojjKHKPhwitxlkOwKJJXXkYoTH/OoTvLWDP/Pxa/3c2pk6JsanQhL+EzZ/3zELuyFrcpllzRlWLt7af0XpiNUcFXXBsLuHHfgYHlYpS4p6Gkr0LIsHi+2Lay9cFCPnadRHK+Nc7FUnQ9OUjhaE3qfhdzO3cI0w/YstLyEjVFprhtAJTt2deky7CTbjStScf8dzl7PgxDKyOSoXIruGVRQ+PgdAQbVkeT2Lgda7fp6J09zsbegZzKKuSp3H60jWYh7hTKdyVb7h0MpGJqHq4ucnT3zGXyjDU0rZ9I4qEXBH1bSca1z2wWncL5gH3sLE6kdvwWbv53Ao3L15FYMpGH22NQUApkpcEwfq1M4mRXDYuPbuft2vccGXuQ0XtdeLlpGpPnjMJ/ggfz/Xu58l2XDa820XdPXxYNesDziz5MV/7AsmX/CKx+Qp9QIdtN77BO/CRtWt/xu7SHc3LqzJw3kPy4KFTejmK9bDGl1wNIObeGnL0t/JiaT9hRcQzKNwnpMAeBuMoblEYvpeHtNzpEahigo8+7lauwCU5hzPsqjv3Xw7lIJ9SfZxD45TvDB+9k8bEw7OXfkmN0gDH5MUioCrCc+4jOymCmPP7LI+uB6EqOJHrDDzr2GfJGUIb3n0yOPFjMNJmZpDfcwSvnBOOGGFNfqoh2+1USZZax6upPykISaLI8ToxIDlaP6ylMsqLL7DXnwpQIbZhG28ZUUgLm8bDvak5vHY1eWiOyX13IiphAietLRLvKWV5zg9THuzi+5TGPFv5kQHYf5vWdzWrLNCZsCOJNuw/bdKfw+8YvBBG/BnLT0hetB0PxibhB/O5JmBS4s/Xyc74MkKJghiJrd15ip746YkX9eLx4KaW30ogslcRrpxHz73dReW4b+xxncUpxLSZ/bvPxwlsGHtPC+sdLPHLWkDxrMEZx3bS896TKuQi9U32Q8uzi2UxVopbH0ed0Kz4LB2P27AFh/yoZXrIPjzgN7q6TQW3yJYZ2B+Cj8Ivx2ptZnRvNqLvVVHOUKbo76FU6S6KjAJOPBijfPUKkyDK89m7gi00dxtPV+HnEDI+O85xW3kr9f2PJKDBBdsRHbJ8+JDsmCUH1DkOWBAuZPv8Cmd/fUb7+CJPGf+X2EjMOdEQz55E3f2VKWOagT+KFctr2uTGz/Qk3o1s4aKvOP7Ek1H+Wcs1XiaHhNeS5mrNRawdHF9ogd+80L0b5MmnVJfqoTmVtwDESFtnxSvkrB9I30ZZ0AJtDudx6ZU/HgF1kaegxZMc4/oxcxKyatVTMukugxymefJzFvOvPqNu1iNf2/TGOHYm7ag57L6ix4vUbPhy+QrBFN5um3OfuAkk+Hj+DxNUxjJE+yvmylUzf+ZX9c8KRSnnO4vC/HPGw5sIieWb1P4bA+b/vFLzMQ3aqBo7iO5G6PZJf9b0kxcygz4G7PNxsyci0Vk798yN3/BmMRZRwn/MfcpOD6V8rS+bITbx5k4fdklNCRIkzLu8cF4e30L1Lmfqm+/hGNHC7arTQ/EwIz6tk5PezLBcby9UKXTb1PkJF4ROf3Ibj1hrB9IRCfFdfJm2xCKtvvGF06A/aJTxxthrC8iOfuC52g0PffBkg00HeYuGQNdUjudOEGY/2Uz9Mg2FnSunJ38a8v0Iijf3D4cZXFMXfxmrVcD49/EBvgDpXxfszteUMrTNdELlUjWDCqPH8s1/OlasRbK94hIa7LSeGD8DA0Fn4REP48EYF1eVDqClfg+Phl4zPnEmdkw3nU3ezfqspi07cI26+FVsm7WVOsz7efa9z91MgU69I4zhxLrOXvmax+1b+6t5ki5QEahey6Vzpwyz9awxcN5AQ1SUY3JrJqANOQiP9xfKHBzkzsZG8zliMdxsQ2TiJpCcrES9u4p/BOmJKNdA5nsCPZxmErhfnXP8N5OhEYf9jBPv/W0Xy1lYmr0vk+aw9tKUPIK2/M31NDdj0Zz8nFBx5ujIdz9u7KC3WYZ9TKoIQDqHr24/YhV18jZ/P00Pl2LZcoSW3gJjjdSzpl8Wus0lc0+xm0LYTHGgQ43jBFV4t7eR7RxyTnvUjOLGXwZvq+G/PVKJm5WDu0E3/wE1kFZ3gTH8Ljv/7ieSxdWTvnMnu+m9k+FpR8uQU8XH/+FJygUdmDcKrucuRuVOoD/ZAuZ81O/JHILLgCe9igtBUv8y2sQo8u3iSSW4lrNeaz5L9HoyuGsvmlHZaw54gsC3ksd8Jlogrc/KpGZuXPWX3Gy20wyp46HKZiS87mK8RgnxFMat2t2I0QYYHJ54hsL73BcmBt3n3dgtmSqPZZx2P0sx95AstT2LNXA7/2s4PeVmemSxkflg6PcOdyYgvwlJCGR2NMioOzeKyUDqe/pVn1EMPfsXbE/i5L2UGn9jqfIVvF0cx9mkmK8fGUnc3EKMZJRyRlUUxVI1tfdxZssMfmsaw1iaE/pFDmPcxh1+bdchMruKo/Aaa1//FPqAAxV5Tqhy92fNAjIyOHupGHuPtxKtMNt7FrpdzWKC4lNgbaShMG8LXizW8PXyY4TtWYKoSRXyNCp8Tpcg/uoQO4zEMOqNPQlsUDbr2CHJqFrJRcwpqnm9JfxbCgO4Wqgab435pLVd82phRFY38jRWce1rF5tapqK/+ioyeAdv3bKdPufAp26/B+HUSRfJ3cLIqYcXRWJKGmDL/thYjOpsp0dhLmo0KMz/257yJEf3avPjoeo/V7yu48dMACa18tF6sxOfKe0qFn7vdm4LL9FPIWu5m6b3bXKuejr+kJPnXzmFk9pAQQTWi4cu5ZP0cvdvTONT7iXRnUX6W+lGm18zMX25cq0pHTF4e27Zf/DHI48ig7WzramDZ8MdEbUvC/7kH1/t8QnH5HgTel8SJDD/Hjw1rOJw2g/NBOcw268Mf1wc8Gh/EurkSfLR5xwo/b06qBFJyWY6vPVHEPpDk1ng/IUstGBs5GD/jRjSrJnBfLQDl3Cx+jNnOmt3nCQ63Y8+IXB5vqMI5+g9dqSlETnJgylIBtYk/ODT6OtkHZRi3YSehmT2s2PWZuMJxTDvcj4ofi5nrEcCgWe50vmzljPdsVtROYmSCMz1Fw1kllKuCIEeGDPqHZWwCwbsns2bRG3L76uIXtY6LaReoXNMPJV8/bt+dhbT1at6q9eJSKsKMtdPpOZiPoP+4y8zrCqBc8h9yX2RYrbaTZR8TCY9SQ+VHDwvzr/NFRgdRj2yuf7jIeNF/mAXZs27RTZ43/sB2SyWntDVp9HZmyFV9qtq+C2tsOC+XvEfw3xAWvp7HlIOnaGp2xmKQBqMKj5J/ZDzzHc+wIsOZH3paRDdEYaJyn5aF85A+60iuUhHf9c7j07eTiPMV3H+riEtIJGqjHfiqd4sstQO4N38hXOYVmjNNufr5HsPt5dh634aJxRF8c9uNge0XtjxTZ/pHc17o3GFN0RvmRJ6ltlGI+SuWLB56j6LM7wjslowls8ACd/27XFtZR9MoG3xeGPDmSjkygs0cOmSBV914XpzZwM8ZAva+XESwUy5Vo9QYdT6EuQMSuPDrFW5Zu7khGUHI6gzmxFiSMPMYEZd/c1fkJhUGXxnyUJ7j25eyfU4pd3pesH9oI0mVBxnpsRynsFpeC4UsVXoz28qPYLhqGomnHjG2bgWrLPR4O/kpw+3ekPKzDzpPuvh4MIx96/UZazGE5ufbiE88QtUkbfj/pYV0crppMHIaj7mvFMTxc58YLKFAstdm9ilI0LZpInfn1HLix0kSvTcgOKj+Bmn3uZimu1Nw9jTK+/Lpu/E4FzUG8d1oP/dWv+JMehgzl7Zg+PMBUoaeJEXWMr1WgfZXbgyyGcqHEBNMJv2BYhFGBiSybKQ6bx87sclhHD295thM8eXSxbM8t3qIzhhxep/tFvq9MR/iRjK931MevZrCYItEtPe3U502ioPfTjPg2Q6e7pDCfNg1/t45ys6YzQR9MsfCLYVbYqUMvjmGhScv8LyiHeddFcz5fRnTOS7svrKQvvtG8ME4lWVY0hDUw68lESzsNOD0k3ZEjubhaaLNiOgdNL4bjmDq4cf8bq0iNrQfM/tPILi2k+x/19APGY3zoy9YN51BSUqG/0IXsEUxGIdbmrz2jOXBtPl4HnjPId2V5H3MZPKmsTgmrGavfikNXfWML9+JtBAzM1yL8c8fgILvVkpru1gbaYdy4yzOmKThNu0vDXYn8b70gWMP9mKv/RKVzQvpHFKP07R3nEhZRy0TUN3YQh9fLQqlhuG00IvTibb87tHAblwWB/XXMKCv8K26iHDy8QHsaj9weeAZZuZtZcOtSexc/wzlSm9eJzlgOzmFrHpf9EfeYv3NhbwbEo9g+Vo77o0+yp4nu6mdq4nNGzNYuo4bYx6hvn02Za/tGKj6kxO7U8l694a/1oOZNOgXEX/vCVfalw3JX7ijeJUzrcGILntJzl1dkgaPINPnFNvHCjFoosNpqUoMb0/BZ0aysC+ErN5UxMlrbuiXinLlhyMWI3X5e1SJs+OsuVNyk1fWfZAX4vWaMcx6F0vc7N2kj6/i24N7yNfnoqIVzMv8PySt2ktF3BKmvo/ibWAjSmb3+bJqKi/iV9ExUpjeU+cg49OXa4JmDusOR8O+jH9bl1Hxoj/jrBsI7/2JwLVCgn6Xr5Ji3oSiylnW7yxF8sYhdgzaweloVZr0PrI/2Z3UTcosarHi3DkfBM/Xors6mcahk1A0H8LPHdpo9/HgxKlvNH/2Q191KYdtYfE1KW7EOFBUFkj/74ZcdvzG/eNDEX80kcLx//EtMB5p3ftCAnjxrroTwZ8EjCM3se/JCSyb/Wgenc2Wk0vwyxXDpuMCRisW8N+xSeze2sDcUf0Zsfcm377NwutWEeenjSJIwRKpn39ROxHGAY+XGLYe5L93N8iOPIdrhiby/o9IKBnHgQFhXL/gTO4sNQQjXRdg9OoF3/xHUdhsTVhCOpnrh2He1stwmxfk5CQyu7s/q/sKB0vrKRWB/7F3wiiul5vw5kQokt87hCJiyaebMazYPwBXHVXUc84z6O19alrdWTO3iSk7Yvk9/CmbF69nemE6RxCe+3YTnkm0cuCFJutTDvPYezCnBJVsna/Op21NTL+QwRAxOZ6sceDdrmKkhal8QfgbghM28OhDDK6LRnIyy43l0tXoW4ewtmAnfy5eZ9EnfTx0JHhoOYawB2/ot3A9S4ca0fIliIxxWxH7DYvCLqK9t4gfqgEIjkV78kmkm60rNzJJtph5z/S4oNlXmJGnOfxpCRNHneCN73y+m7ez7fotNOq1eTH/NHYx+QRtriBmphNGKg+4WvMWGYfr3NtSTe/FTcQcWkC+6ASGb3hD6JM+WJ634JOfAufUPvHTIBLZMyuYY5XDjWZ5pmpc5b/Fi5h3q5BhDkPpUtlG9H8LSMmYjP6SK0yo3MIf9Zk46kui6SfU6C/v6ZqSifjp89ycu5CnIeKIbP/Bq8FOXNl7icrsWlaN38PYxKXCUvzF7LWDWaNVz4nUbDwtHPmqPxeHR0M5++U+gmk3o3myYCaWPePxP3Wc0uo2RCQ2U21Uj/MdJaxV1nIn4h3xjsMIyXJh4XYLumX/Mm5ZX5yLtlPvN53sMzJMNDYmQHwX7/+NZsyoHHYu6SQx7ARz1G/g161FltIOlCp+Y3z1CLv6TKX6nRjRd9/hfnIjP4b+4ciHUyTFPsL+1WpedMbgr9PNugNl1Jw+jLfMF049jiDj2x1E17WyWFKPcZdVOfvvN583O7Cv5iWTf2gSZTSeOdeFCrzhCV29M4kfsIVd+feEOxNOz9lJTHEV5nS1HE/lPiIp/DvukV6O4Nf7ZAZ71RIz8TG37vvi6HIBzT3T2N15nSuX9mLocQ/FL830e6PKV6kEhv45SkaKEucf+tK//xNmdCWyVP4Iv973sC7VjoisGZgpB2DXIE5dhjXpxXvxsK6j+WgiIq6vWNs0jzzhpUzcs41l487Rb5Mexf4+mLcrozhGh7tB/kweloyYcz8Wf1hO2/jHyP0Zxqst49l8Ip/kMXupzvVg591Q7G0UmSniT+nYdDY+iua78LoCo2yxGt6H25WtTJ93mdzdIwiwLmfIiAPEPD+D4a6bjCnaI9yS4yR3CBDMXb4Wp0Mj+Jq8CHntgXwvWUn+ko8MG7uAiFeF/J0zhGdiK/AL3oWTUR5F6tew2vOBfVUOtK3T5/GtBrZvV+aiVS6S4WEU+jejtfYc3ww+IrZdlwmXn2AkLcubeRuJyJbgmpwdAVFtZPyqoXGODBdqniAjxO2eBbb0epTgYtlOY+oYXj97wdGFPtxM1GWW7UYsb1xEtWQRnUKFPjzrGgY7iyk49JWQ0iUMTezP/TXfUPJzZ0dTPm8XG9HfPQ63WFVMJ9kxqlSP8tACVoh1cmv6DI5edGOzsDwtxr1DMOH0H4oH72RX600MVv8gRDSbJce2ci92JHW2h9meqY36pnA+tf/i8gVjJtpLoxM+g/Bx33g/L5rhRwdx7Mt6qtVuMX+2OfvbRXhSepVr8esIGaiE089Iuvf/5fwXE7TN4pC/9wCmj0Mv/wTHLZbgeP4gM8VEeDrtOmEvZdH/Z0pcv83MOFnD1hYNpMVPkqDZwce9n/Dt54hEzV+enNJB9qcMadOc+GeSglm+N5dmzaVx0CgWlITy9PZvQoP2U5uVQ/u3Rh4ZebLxriid/9ahGSDLvsavlDo958ELIwRhHmNI/a+AAQbhPHsyh0sfJ6KcFst6QExG2AnVX1ip+pSwmyKYya/Du7iW/1q3kvb8NgvMl2AvVczUl3u4lTQSEcEHOry3smXEVORyvvNxZgFWDh5kTjrC0FNT8LxQycoB+yjzcmXQkZm4Sl/m7fVu0lavp+ZLNJZ7K+h79iipc29RucuelavP8rdwEM+P3iPySwALDSfTeD6LVRuDiB1ew9SvZ9hyRh0xN2Fuh74n+pcl02xuIaU0jhStjdiJSjI3+TbBzscYp3CBSyszhVVphcDsFCMkr9J796BQhTXPYqegTtW5TWjt98d9xH90q0twZNsqCgJMObdgM+2nxzLSK54HyzLo8T+EZF9F3LaEopAwhTO9P8D+IptK5pLr8oXIu1moLvXFVLjie47cETb6AKZWfuXQa2s+O2WT81eURbYd7C8tRrVNni7XF4w6pYbnW0MmKu/g1e3B7JX7x+g6FR5OamRiRhHrhXbYR24o27O9uK18mrGPFtCetpLdA17w37Px5Mj3EFB9mIorg3DadYE/OUJU1y1m4qrZnNn7gcHvxrBD24QldT00epawWmU28WUDMO6xE6qwxUdkrsvww66JM98tsd58hw9mJUg1H+dGhjqT+1dw8IMvb7uX0e/xPNbOKeFlnXC1NcRpzsjk0W4X9isfZvFhG5QMJ7LydwQXIqVoUlpGsXs8/YWE6ZR8g8GuS9xS1CNszg2ULkeQMtGYJ08ciB69GxOdBoLNH9J++CLr7LT5UvYcc2M/Qi/IE9CxFV0LG2qjr5P7tx7NHWM4Zv6dEvuBzAv2ZeluM9KXu6I45TOzDFbzSmIqN88UY252iC/dURQN+0Z6tCtlh6cKVdkfXRFJbpzZwbYT6TTsEdZgYbYpzkcy2Vd8WfjE+zD61Hz08rzxTnzCV+3hLFp1DdeQVyQqt6M/VJXTyRfRXCdM5lBrXn+aycCRVWjH9uN98z/qxTMIvLJG2AkVjMj8hU7bIa6eHYHb8tVU3vFG/IUya+qH8v2kE7ULqpiz9xz28YMY3HKc+zljSexThmbXEmK2OCHx9CpvDszjsswpfszuYuQ7TS4GJGA9/TXOn1zo9yOdFB3hWJeM4OSfKH7dT8XrkAF9mh8SvNkD2RP/WHurHzOm2rA5/wosu4/Mr0pUdeN4UfyZ0Y7K3JNxQzC7U5vovnsQnXMUs/LftIqPI8d6I+GKZ1n1308ePR+Ikus2ahaHsTdGlp+dq0nP/YLy4CiSVqSxwyRfyGgTpGfGk1Lmhb6NAn8O5LJ+XRInhWP2rLAZ298ZTNA8zvmDPWiJfMDDOZC+HVM4PDidYuufNNy1xtlzCyOGtZN9WRq9iNP80qzHRaw/00Ifsex6Gd52RwgT9KU0aSm9UnN4EHEcvzGJrHFp4VO0NipDC0hyVMCyYC/NE6Q5Pecczz7O4IBXHv0G7eFK6jBsxy9j7xah1CWt5khtCEuN8hF0bRajLD6aWztWonIlj4CuUpIDFqMR/xWB9yz+DrND5+oCXnx9iM3ecuQMB7B1WzZf1eaz4OY4Vjfs5/eOYdzZ+Fbo7VpMkg9B9KUeuz4PpEZXFfPjZfiPUODV2gUci8nj3ZJt3Pu4jOU3mzhbIMuu6fOZWvGKP8c1OTD/MDYNJXxavpKdJS9JX7eHgTXmPM4ZzxePNRg05SEurMYp63sxzZtCy+dVZC/cyZlbfTDWOsrmTz95f6GC+33MmZ/5lLF2a6hq/0jrgkksWHeKqMZfvD3wAic5eQaqXyI54y+CVeOr8aweydHH26hfM5WNxpeQeShH+bS9bO+JJF6vhqCC8Qzus4fr6SmEVi7mvYIrfQN/Ef/9GBXn1qHWtxWrgsu8YikBpj/4kHCbs1v3MG2iGYN9nvDrqg2jmqLY+UScharCvt+uzbChWbwI8GXMmkgMFFO4/qcP4RvvIDLJC+X0MRwdPY0zPt2s+n2JAlVXxioJh9R4FDePphI3NwvPfeIoXHyHdv9FDNp5n33fnPm+ZAXDhE4iXAF2+oZwSV6OpcFGBCU08+jBJuRC+zAz5zpnV/hR802dsaeEJrhAIpURy4VGp9VO/ghdVoTepbN/IHedJbAoTeONXQ7rg9fTNqkH1ZmHMbfV4HnEHfxfSwuVs5TH89Q5NjYTuQB32qb2xezaf2QNdsDhfSyt93pJsd7C/coU5hlN57NSG9cSVzO59yybZ4vREuFK8tUKKhetwuJiLyX7F3I/7yyt8S0Yt+gzal4IlRelmW2VwZbTM+n6EMu69gXkyW2hevlnQtTGsvLpGRqOtHF1bC65L6Zz6lQMDoYN/LnqSVFtJ1Kvk5g8+RBbZR7RXaFNWv/tmM+pZ+f1Il4edEKQmWvEvz8BRO0fwuD6chJeO6Pb8hflm1b4mmoiG/UWw+8CLm06w3+XRuP6t4hZj+qxk95B59UENi1bgW6lInvuRnHB7hDiLZMIP1rMnFnSKPUE43G6AesBAk65HmD9mwoGHlMiemU3fi9L0PlvEcfbRrOunwpD3+7BU/sxswbJsCnYiWTT6yBZyd4Hy7jmt4uowW1IXX6NhpctSwr9ENwJp6PnJner57FxpQ8Trkkwd/BlDm3wQ3R6P25KzmHT8lfEuQyhTMeKlbvjyV78jj5/zfi6TYJpbyM4sX48gktTmtiQfI4lp1fxXi8Mb49JPJ34nFC/eq6O2srvIcfJfbyI3T7NSHzQJWqQLS0Lwrm1vx/K6sZc/tlJ8emX1HtXovXUEKdhmyh3echtCx2Oyo0j70UBQwN1eaf9nOnfvHg2JIyavQasHBnE3QU3GDDxC792vkT1YSjnVtTypUuLvDVvsPPyZ1rlQPoX52DpHMm3fyo8mDGAUsdqkkWH4X9CHV2XbiKl1yA9T46yuBqWdxrwsOAPjZ8dML63Ga2YDBp+TWNvlg/zkr4StkaJdVGOBMh28u6cMLdNdiHYXzaKSXYzuC1fQEv2IhRSRXFdFsvn8wsQy5VGs/oBK+cKpWTMLhQtbhJ4fBP5Hs8Y/FWFHdlXWDxqHyc3ayMYMISHBtf5F5/AiNpmfHy9+ZpkxYKpF+hZvYGE+7fwPruU9sXSyN18gJnTVAqy1vDpTAK7Xefy9NgQjtS4oSC3iCHPYoi8OoEn6g68OQ5BI+dhvGgDE54G41OZiYNyMk/PLmey6TOKS4LYdeA1Xe5hxE62wGPRYxSPviffcxzHlE4zKKCaq30MGPd5KK2Fzxg2PZn0piNY359L+8AyBHoh2VTv+EOfb+4cEdxCe8N3TDW8cey9QpmnIzEOv9gWdx7dW2VUtA1CeFUkqPijkfCWMrsv/A5ai+KbUGy0trO1+w8p+YtZMk4O1TsfWPvhBP06fhMgpMSEuslYKDZxuaCIkN9ubA37xjhNUWI/7mSB1G9sblmTOvUqZYbfWRz1jAPtnniMTaJp5Qfk6kfhfPs2dYEdnDXYhqzPfP5+fc+WVBFMpruS2KKMxv07DCzbRtXIs+xPluXCvCNYfeqiw34lD42uY3rzJAWj/xF/WI3ZBltQ3NMX958rEITqhFBwezJ2pge4UjGCP0c+8PrhLO4rCvX35GuCvvjxTW0G1/0tURl+EtbJsrFyFgsEFty/Lc/+hRnE1Q3lZfIr5luqEhgSQMnaNcTOE+W5SAapZkZUyVTiGnqIx/qRzFWdjWDrRXr6LOf61wA07N8iY6YsPPH7uF08jK6/PN3iAsZ71HP71XRmzDXhQsI+8geeIzR6CbPbxjJ4WAPlj/ZyQ1ido0d/52jELHJEGljtOID5u9X5192C6kBzNmR7MrJNgOfk1xw+vpGKLb44Wy2hu7qay+Ojydp4DcGIoSaov17H9gmJREX+h3THCiGPj5Lw7ilTB7ayZOFwRNw2U/Q8jwMp/yGln0R4ZCaNs9wZ0BOD475fqE9YScXDOr5t1WW89BMk29vo3BOPTqwGK+w8CM29gvg1G1r8BrPmA7y1VGRfShV1h57hlD+cl2PjOOXtRN8XH3kgTOy4hnDWCJFWfv8uhvtC6PuzEftt/filVkjmihlY54VxcLYk64NW8Z9w1Notk7DI8ePueVtGzCwi9c5V3i+dRVRUDi+czjPzkgq2H+YwYPB9VF/KsyemhUWXC2l4OhRBwufvdCRkYbG/Py+s9NGXiGGC9yY80gbxw9aM8sJINv2+y6V+ythZLeTJjzV4en/nddY0UoYFctTJkOHhF7k+pD8bysIJn5bKvrQJZNS/Ycvj/chP/kLRv9FobXrBTbGNnP7hw5SMNKzl1bioewrTKDMOftOhol8jU2bvZs+HKRRN/INE8muOizjTsUaK3WXPSFN0Z8prezw3XeNN0h9ihuQy/5MqfT0/MUn5AfsWyFBSA6EhJ3HbvAnzN/sQGTqcGo1GLnkH0/W1nNsZYkJDTKCsZw3i/TRZbeuFIGBBGW/dwhkgbPS7ud3UJt5mnbMaNz438GxiMieO7kD7fCfDtSRpKDmKXvBepo4VNkNqIUuXVVJTMI65rbvJ0itjoP8mlp3dyQeTZRjKSVEnfEMJ2x/yt0KPRRfjODDzPdnRxoxak0nHbkcG1W4l81EXis63+HdNDAebXGbFraI5MIGUHn+WTR/D81NzkUn7xWHTyZgcq0Gh+yAt+0Yx3TydV3FeXL19jG1Fipz1X4+EpCFffmShM2YQAZkfafNPZ8Lf1fiYmbJg+HfkV20nW2iCwVMN0PY8yIOTt4QiJG+Fy/WZTPm9l5CqXLpktzFI+x3Low8i/2QeRnJ2+Gz/RF66FjFOCfySqudmmVCEtgzn+xcb3KanceZSNr0O0/HqHUlT9j9UXF6y5q02orOPCX3/FzuWDxCanApfTX7g8vQ4Bo0iHFdpoFhiKLMtXuOufoiEkGXc7LyM+YgRyHk+xrNoIdP0y3FpSeWzdBilz85wT9uQi/02InZvOcv+iyZklB6PZnTSu/EVWl/isLlWzdOpE1CwXy4swp/Y607lcVU0p64rsFE5jcbIFVgUheG++DeUKTGudQiCq9mufHO4wF6xVi4cW4hOhjQ7FlsS+1eRz/se8We+KHdbCxhvfo3DdUsxm7IN0TPzWb3gJJnCYRnfv5OFXuYcSj+G5tjbXOlrRPSKJl40RXMjKplp95x5+K0Ku6IApHdYkTRsBjVBydwVnuiuJD1st50nolyJ/s9deDX4B4fTZ1K7zJPTCoO58/AbSm5WzPXzJtJqKGu/PuZ3eBm+E0TZ7P6Z+g5Xhq0chLHodEpP72fTrht0mm/n/IdLeG07zOu++uiGuDE4+z3vnA+g/lOC8+fV6DMymaL0YiIO1yOQnPSQyrhRyOmvxnZnCB/XX+FVcSMH+8Qz3eEvyWUnEBviinWEPC6+vynKnMgl8vi0qpnwFzMYOvoM798PxN68noKaVYwO3c9+7z4MnfqJXykKGK015cO+G0SFepF7q5gZv+Q5ZNuKhGE2auE2lPVW8GXMdCbuD+W7cREbvv7HkKOneVl9i95VG/A/O41ClXdYlv9A4sp4tNcm8mKBDinvshkbmIpjih0Hc1uI0lvCoG4JJo3QxuTZZ462vWZ4Sl96V2RzWeovfrt0uK/3mFV1VdSKbGCn02KsZgUj0NoHGxpUefr+PQvHCEj78QTlKROROrwex7TpvH2+j23jDKlKfErryrVIzo4R6qoY23weon7Tn68/FYWZ606f6ALuzLiE7pPJfPn1iKVS29iUZ0vIyGm06j1n4BQptvc5Q49LBqaam1mfO5GfA09z0fEPS2bfZX9sX+Zv3MsjtcVoJk7EVicYo7znCET7kMAh2rebMGm4B9sLj1J5/i+n1Pcw99EkWoV6e2dcEPnHMtma0UP12pM8OGhD44wRTB+3G6vX59nSZMG4acdpDxrJ8MxdzLOK5caVfrxEiOSDUldpXu5B1MMYBJG1/L0yFzcjbx6cKcKs/hbHNCuZ6yJNdGcLk18d5v6oD4RU+vAneQmWapfZPa+S59b6bJT4RfcWGU5cC2er4TxeH37NxaVHGFP+mVmdvaRe0GXZu9WMr6vl9VUzTh4I4tYDcUZ/3sHz60ZIv3tG6kt7vL4P56T7PxIl9Ci/+YWN5mfxDirgxjxHjj2+z+Pd4owcaMHiPxGUSI9A1MsYtebzJFZsQU9iDH7ncrGr20DfhfeIjfhGrtD3j99eTfmiW5jmfyZe0ZjgiA5+b3/OmMIDCM4nGHLP9RW7NC2Y0/8gxxsdqHNv54yUOd8tB5LtE8Wo45akGSbhe2sqDofm8nLJCIaf+sstV3v0P6sR9CqdsecPs6jNkjJlZwavb0et/ioZcYPZ43GatZk+VDmMx29RKI9Oi3F21E/6Kuswd+lr3Has5+goRVYJ2ulZEcP7sR9QiEymafdWJv+05enb0QyLnkX9mGsYtFdjv0yDfyfySVu1HqePtXjHZdCxSYCVzhykV5TzW1WNKzeu8m6AERv3CFP7lwa3zpXSX3i1Pvs2k9VxGVXNibhU2bPYWOgBYq13cXg5lvEnuiiwl2SZ7ylkC+RQu3+JPb/dEZXt4r8P41jabxU/v9wV9nsdCye4UfP9FTEiEQy6N4Tvjt7CcCpFY/8z4t+MI1O0Ctv0xdTNGInIuPW8GPiQ6MDlDNMpo23bZRx69vG5+DZ7zzZT+e0shSeuoWrqT1zgbBZlOiNW+4At+hIECw3Owm4fOhu7KU49SYzGSPrXtxBwewcaeknE+XfxRM6fY9dW8el1Mwq+sYSznxl5A9m1uQ65sq3Uz85CRS6A7s+/Wes6h+LkfMQdjtEoJhzGCc0I9A/68GPYBj71JJI0fwYBn26zfsJH3s98icE6HS68OMCm+Cw0pryl2OM4Oy6IkPjmPE5PFzDFIIuSoCY8VNZTXTGT1aai+IadYYRwNzpspnL4TwFmezv4dyOBya0zMHz+ki3iHmgeU2OMvh0ZG2RYqL4I8U8qtFx+hfZfMQLWNpI3fDr30o/w++AirkrdZV31ZNqytzBhpDUeW+L5cK4fTRN1GfJTlQkvFFhg8py1Ai9ebjUh/UQJZopHaVkqT1ZWBweDF3PRdhiz78URYWiN1ZvRJB/bhleWFidvRiB4vqiSqWsH4576DOnRX+m6tJnMpRO5HnYEmxvG/Dn4mSBzSe7+8eLUA3P6z/xB015/AodN5lGsIiu2HWXu9SSk/pryYvZ1mlPAwDOEiOFbmHH8FsnvDPEyOSjksoCCST18bJAlyDaSy3ef0S3zgRVPjhHmXovLPE/SJllTe+YUDq/Hore0g5HNl4hMqmFI6CBhcxhz/0ApyR8OYSL6FJuHb8lZsRgvzZNcjLjC5++S+Gb24jrfmolf73D2ymwGSa5lqXoKWytLhH+9nSioPKJh6H9o9V7kzqw+yO5ahiCweBKp04KJ/U8fs2d7mellwcAfvUT06cvor+uYqHuDlwrxSNlrseCkHB8HpqJjuQH5rtf8+2SFz+KfhL2U4vyAWpQ25LKjdgU3p8xhU9NAinU/M9p5JQ5DlRBfW83Jwo1Y7DZhgLDNn1XMY8dBUSZ2beTCkF6yXs2nz/6bjO33FG+3jyTozGPqCy8qt6/iZf9srHrb0dK+yn9rJiDd7Cg01Dvc9nSj5782RmwoQ1PoFyKXJvBmsgusOUdwzAvW+EymvDuUn+79kXppyHv/qfhatmOycR1/4+6w5usfBNVh8VhutadJ/C27Y4aRc+QcDRsf4jbsJOXvC/HepULzVUscq3pIKMrGvbmG7BuzubFpJ+ZjbiPQiOXzHlcyoqawRHoH7w6NZvKyVvrFP6Y6N5ynl3fh3/GaVs1kZp86xi+Le6zrv4PoWRcZOsEPvUWP+BCugO/KBLglzfKy/bz+vZ7vpwUEKsZhOk0OZxs/eu9FEBQ5B4VXMhSYw2bJPcy6OpBypTNYvLElKiCQtCUPsCmrZu7AvgwtbOLVwn1Mu16G4bh/XBO9wbGWYJzvSDOg/AB5CgsZJ3iBYNbD7fTt6OTOipsozpjKKsNqjhbaMu+eIolnv7FkqhvTXUo5KB7Ibz9HLFUiUdbrT1RIG+sShlHUUIq6nR4HSw7x88lp7H+8F2JnHd2KFznjK8NywRSUq55y985sLiosYzejUXN7R/2NyeQ3t/MjwZINO7UY+SUUI41OQk1MuXO0EMlVqXhc6+XJ96WIvJvGJZ9i5g/dTmzSf3SoHmdv93QmPf+MY7wch2cb0N5SyJN73nh5jeC/jnASj+hyR3s5exrkiFzlgt0leybPe0XLjtNcUPvA6SRZdhlrI3A9OIafY8MIKxel5I4bU3oP8m/SLO7ZpyCyeDcl7Xo8ybnIyJhBXDOdwEDPhfyXmYnvq2Dah07ncrcFI64+x3XSb3SNxBnkdo1ULQ10yozxcPiIodlmPm9tY+MhKWTnx/Lu8W9MhT6QekIcK8c0Aou2oiFfwYOn+TQk2jNFXIU1I6uZXTWTK/7HaDJ8zKRzTZSM24BnfV8ctjzg0WErRFeZkmr0knN7b1Ik7APxlT8YfyoRE01zTo75hbzLdlyys2iWvkifsAYK307gnvks5gUvYVnXFj7mf+Oh4zUEQXOWYXC+jqHeBcLkNcUkJQtfvy6GjRYjtiabDcHDqJn9lbCR99H9K7TCS58osL2AVp/NSPh/wXjOZSo8HTktN578kPvUX1rK3iEHePz7D5JhwQRnWpM35QanG/fQ98J/PLZTJ0TmMEpTC/Hwi6RfX2OS9QYQ6xLA9s5kcq1HUvHAh9NerozOk8Rm4HVObBxD+vILDMvUZ9q8aEorPrJwRArf7h5AvkYZfbcTbHo1GL+hUym97khnbT4zEtJ4bqXBoozDjNsziKr2h3iOqGTU0xR+CdN9iFsmaqWBCL5Ib+D517lsXH+JSrMmtgmfVK77WmyiTtP0+D1GokvZuT6ESXc20lmnw4Nx3VwoXYFNqzzHN+Sxc9F+7j8UYfn7E4z65swFqzrWv8hh7E5RSueO5fuIc6jHzmdH3gCsxV5QuWsLOrV3aTeZQ0ZXIx/Tx9Fc8YTFk52Q8f1CQFiGkPVRdM7+xu7Jxry/8xbjxpV0hezBt/MndX1UsCxy5uTpEbyY3sO29jk0KL8lPbEOte57nDcNpP8+JVb2kSLwXytxBib8GR/Luo1bSYndzymtHvzTHFm1dBpXosoRyGYOYsW0A8TljWLGyR20NR9nvNRtrs4wQvO3J0HecPvNFMSXp7HmxCtMt4jzUWsnY6JU6bljQHZQHBNr22jtV0RQrBrTnObROyGaFQ3buX35LuYlVcit6+DqsnX8+x6On44Za07LIpFjS2TyJeZu3YXyMlgVN43uN3rMVxzExXWWLOU5zxZPZHp0IBtk6xDTEif+ch5XfINwWfQEybT+HFzvxcwT8UQvW8Hfw+4snmdI3tMzbF9TSf37jaSFlKA7zYb9uT+R/iSL+kpDnviF8r5OCZOJ5yj8l4dgz8pwelP/0k8+g0BdG27fH8wQmyrCz2vSvXAMo684kKcaz9cAWeIGmuGXE4ao8Q+cZe8SU1TL7MnCTLU359rMG2zb780C/R/k3B1J+BEHDojmc/avFhsO+FM8fhLzU6+gcuQTlzZ1kyvbl93jS3A5doKSQUs58f0sWUYF3EoNwlXkNxMurOVYYDxpn3T44uFBbraQIqssUJqoSc+2Nu78W4XK6LtUPmvCdsBoBr19zjFPAetU/vEwRpthI3ahknaK9+6TeHnxBVZiaXz7pSUUomLcvOoZ13cXEceMEajtu4Ke80SedOSwJFCHNxM6cKg6j/fmIkpfHGHzmFqsWh8zS6+Jx+f8Uet8Q/P1RG7uWU1hdxD+km4MO/eOPtk2vPkzmBrZC4wsL2XwEjPmTA+lcYsQO0bLOV79mnSp0dSVejH80SF+9zxg4dy1XK8fjdiaGvbfl0J+xg00dnrS/FSBj6/LkbDtx3bxh4zq+sdho5FYvKtm1/kICiX1WPDxPWvnHyJrnymyTVO4ejuCd6P8GFN9Bf32JfyedZewZWJsbvFl4KH/SDAVNoeCCNVz79D3nBU/30qRbtjC/wDretpKF+v7NwAAAABJRU5ErkJggg=="), V = new h(baseVertexShader, shader1), W = new h(baseVertexShader, shader2), X = new h(baseVertexShader, shader3), q = new h(baseVertexShader, shader4), Y = new h(baseVertexShader, shader5), Z = new h(baseVertexShader, shader6), J = new h(baseVertexShader, shader7), K = new h(baseVertexShader, shader8), Q = new h(baseVertexShader, shader9), $ = new h(baseVertexShader, shader10), tt = new h(baseVertexShader, shader11), et = new h(baseVertexShader, l.supportLinearFiltering ? shader13 : shader12), nt = new h(baseVertexShader, shader14), rt = new h(baseVertexShader, shader15), it = new h(baseVertexShader, shader16), ot = new h(baseVertexShader, shader17), st = new h(baseVertexShader, shader18);
  function initFrameBuffers() {
    var t = mt(e.SIM_RESOLUTION)
      , n = mt(e.DYE_RESOLUTION);
    d = t.width,
      p = t.height,
      m = n.width,
      v = n.height;
    var r = l.halfFloatTexType
      , i = l.formatRGBA
      , o = l.formatRG
      , a = l.formatR
      , u = l.supportLinearFiltering ? gl.LINEAR : gl.NEAREST;
    g = null == g ? createDoubleFBO(m, v, i.internalFormat, i.format, r, u) : updateFBO(g, m, v, i.internalFormat, i.format, r, u),
      y = null == y ? createDoubleFBO(d, p, o.internalFormat, o.format, r, u) : updateFBO(y, d, p, o.internalFormat, o.format, r, u),
      _ = createFBO(d, p, a.internalFormat, a.format, r, gl.NEAREST),
      b = createFBO(d, p, a.internalFormat, a.format, r, gl.NEAREST),
      x = createDoubleFBO(d, p, a.internalFormat, a.format, r, gl.NEAREST),
      function () {
        var t = mt(e.BLOOM_RESOLUTION)
          , n = l.halfFloatTexType
          , r = l.formatRGBA
          , i = l.supportLinearFiltering ? gl.LINEAR : gl.NEAREST;
        w = createFBO(t.width, t.height, r.internalFormat, r.format, n, i),
          s.length = 0;
        for (var o = 0; o < e.BLOOM_ITERATIONS; o++) {
          var a = t.width >> o + 1
            , u = t.height >> o + 1;
          if (a < 2 || u < 2)
            break;
          var h = createFBO(a, u, r.internalFormat, r.format, n, i);
          s.push(h)
        }
      }()
  }
  function createFBO(t, e, n, r, i, o) {
    gl.activeTexture(gl.TEXTURE0);
    var s = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, s),
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, o),
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, o),
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE),
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE),
      gl.texImage2D(gl.TEXTURE_2D, 0, n, t, e, 0, r, i, null);
    var a = gl.createFramebuffer();
    return gl.bindFramebuffer(gl.FRAMEBUFFER, a),
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, s, 0),
      gl.viewport(0, 0, t, e),
      gl.clear(gl.COLOR_BUFFER_BIT),
    {
      texture: s,
      fbo: a,
      width: t,
      height: e,
      attach: function (t) {
        return gl.activeTexture(gl.TEXTURE0 + t),
          gl.bindTexture(gl.TEXTURE_2D, s),
          t
      }
    }
  }
  function createDoubleFBO(t, e, n, r, i, o) {
    var s = createFBO(t, e, n, r, i, o)
      , a = createFBO(t, e, n, r, i, o);
    return {
      get read() {
        return s
      },
      set read(t) {
        s = t
      },
      get write() {
        return a
      },
      set write(t) {
        a = t
      },
      swap: function () {
        var t = s;
        s = a,
          a = t
      }
    }
  }
  function updateFBO(t, e, n, r, i, o, s) {
    return t.read = function (t, e, n, r, i, o, s) {
      var a = createFBO(e, n, r, i, o, s);
      return V.bind(),
        gl.uniform1i(V.uniforms.uTexture, t.attach(0)),
        gl.uniform1f(V.uniforms.value, 1),
        U(a.fbo),
        a
    }(t.read, e, n, r, i, o, s),
      t.write = createFBO(e, n, r, i, o, s),
      t
  }
  initFrameBuffers();
  var ht = Date.now()
    , ft = [1, 1];
  function dt(n, r, i, o, s) {
    gl.viewport(0, 0, d, p),
      tt.bind(),
      gl.uniform1i(tt.uniforms.uTarget, y.read.attach(0)),
      gl.uniform1f(tt.uniforms.aspectRatio, t.width / t.height),
      gl.uniform2f(tt.uniforms.point, n / t.width, 1 - r / t.height),
      gl.uniform3f(tt.uniforms.color, i, -o, 1),
      gl.uniform1f(tt.uniforms.radius, e.SPLAT_RADIUS / 100),
      U(y.write.fbo),
      y.swap(),
      gl.viewport(0, 0, m, v),
      gl.uniform1i(tt.uniforms.uTarget, g.read.attach(0)),
      gl.uniform3f(tt.uniforms.color, s.r, s.g, s.b),
      U(g.write.fbo),
      g.swap()
  }
  function pt() {
    var t = function (t, e, n) {
      var r, i, o, s, a, c, l, u;
      switch (s = Math.floor(6 * t),
      c = n * (1 - e),
      l = n * (1 - (a = 6 * t - s) * e),
      u = n * (1 - (1 - a) * e),
      s % 6) {
        case 0:
          r = n,
            i = u,
            o = c;
          break;
        case 1:
          r = l,
            i = n,
            o = c;
          break;
        case 2:
          r = c,
            i = n,
            o = u;
          break;
        case 3:
          r = c,
            i = l,
            o = n;
          break;
        case 4:
          r = u,
            i = c,
            o = n;
          break;
        case 5:
          r = n,
            i = c,
            o = l
      }
      return {
        r: r,
        g: i,
        b: o
      }
    }(Math.random(), 1, 1);
    return t.r *= .15,
      t.g *= .15,
      t.b *= .15,
      t
  }
  function mt(t) {
    var e = gl.drawingBufferWidth / gl.drawingBufferHeight;
    e < 1 && (e = 1 / e);
    var n = Math.round(t * e)
      , r = Math.round(t);
    return gl.drawingBufferWidth > gl.drawingBufferHeight ? {
      width: n,
      height: r
    } : {
      width: r,
      height: n
    }
  }
  function vt(t, e, n) {
    return {
      x: e / t.width,
      y: n / t.height
    }
  }
  return i[0].down = !0,
    i[0].color = pt(),
    window.addEventListener("mousemove", (function (t) {
      i[0].moved = i[0].down,
        i[0].dx = 5 * (t.clientX - i[0].x),
        i[0].dy = 5 * (t.clientY - i[0].y),
        i[0].x = t.clientX,
        i[0].y = t.clientY
    }
    )),
    window.addEventListener("touchmove", (function (t) {
      for (var e = t.targetTouches, n = 0; n < e.length; n++) {
        var r = i[n];
        r.moved = r.down,
          r.dx = 8 * (e[n].clientX - r.x),
          r.dy = 8 * (e[n].clientY - r.y),
          r.x = e[n].clientX,
          r.y = e[n].clientY
      }
    }
    ), !1),
    window.addEventListener("touchstart", (function (t) {
      for (var e = t.targetTouches, r = 0; r < e.length; r++)
        r >= i.length && i.push(new n),
          i[r].id = e[r].identifier,
          i[r].down = !0,
          i[r].x = e[r].clientX,
          i[r].y = e[r].clientY,
          i[r].color = pt()
    }
    )),
    window.addEventListener("touchend", (function (t) {
      for (var e = t.changedTouches, n = 0; n < e.length; n++)
        for (var r = 0; r < i.length; r++)
          e[n].identifier === i[r].id && (i[r].down = !1)
    }
    )),
  {
    update: function () {
      !function () {
        var e = [window.innerWidth, window.innerHeight];
        ft[0] === e[0] && ft[1] === e[1] || (t.width = e[0],
          t.height = e[1],
          initFrameBuffers());
        ft = e.slice(0)
      }(),
        function () {
          o.length > 0 && function (e) {
            for (var n = 0; n < e; n++) {
              var r = pt();
              r.r *= 10,
                r.g *= 10,
                r.b *= 10,
                dt(t.width * Math.random(), t.height * Math.random(), 1e3 * (Math.random() - .5), 1e3 * (Math.random() - .5), r)
            }
          }(o.pop());
          for (var n = 0; n < i.length; n++) {
            var r = i[n];
            r.moved && (dt(r.x, r.y, r.dx, r.dy, r.color),
              r.moved = !1)
          }
          if (!e.COLORFUL)
            return;
          if (ht + 100 < Date.now()) {
            ht = Date.now();
            for (var s = 0; s < i.length; s++) {
              i[s].color = pt()
            }
          }
        }(),
        function (t) {
          gl.disable(gl.BLEND),
            gl.viewport(0, 0, d, p),
            rt.bind(),
            gl.uniform2f(rt.uniforms.texelSize, 1 / d, 1 / p),
            gl.uniform1i(rt.uniforms.uVelocity, y.read.attach(0)),
            U(b.fbo),
            it.bind(),
            gl.uniform2f(it.uniforms.texelSize, 1 / d, 1 / p),
            gl.uniform1i(it.uniforms.uVelocity, y.read.attach(0)),
            gl.uniform1i(it.uniforms.uCurl, b.attach(1)),
            gl.uniform1f(it.uniforms.curl, e.CURL),
            gl.uniform1f(it.uniforms.dt, t),
            U(y.write.fbo),
            y.swap(),
            nt.bind(),
            gl.uniform2f(nt.uniforms.texelSize, 1 / d, 1 / p),
            gl.uniform1i(nt.uniforms.uVelocity, y.read.attach(0)),
            U(_.fbo),
            V.bind(),
            gl.uniform1i(V.uniforms.uTexture, x.read.attach(0)),
            gl.uniform1f(V.uniforms.value, e.PRESSURE_DISSIPATION),
            U(x.write.fbo),
            x.swap(),
            ot.bind(),
            gl.uniform2f(ot.uniforms.texelSize, 1 / d, 1 / p),
            gl.uniform1i(ot.uniforms.uDivergence, _.attach(0));
          for (var n = 0; n < e.PRESSURE_ITERATIONS; n++)
            gl.uniform1i(ot.uniforms.uPressure, x.read.attach(1)),
              U(x.write.fbo),
              x.swap();
          st.bind(),
            gl.uniform2f(st.uniforms.texelSize, 1 / d, 1 / p),
            gl.uniform1i(st.uniforms.uPressure, x.read.attach(0)),
            gl.uniform1i(st.uniforms.uVelocity, y.read.attach(1)),
            U(y.write.fbo),
            y.swap(),
            et.bind(),
            gl.uniform2f(et.uniforms.texelSize, 1 / d, 1 / p),
            l.supportLinearFiltering || gl.uniform2f(et.uniforms.dyeTexelSize, 1 / d, 1 / p);
          var r = y.read.attach(0);
          gl.uniform1i(et.uniforms.uVelocity, r),
            gl.uniform1i(et.uniforms.uSource, r),
            gl.uniform1f(et.uniforms.dt, t),
            gl.uniform1f(et.uniforms.dissipation, e.VELOCITY_DISSIPATION),
            U(y.write.fbo),
            y.swap(),
            gl.viewport(0, 0, m, v),
            l.supportLinearFiltering || gl.uniform2f(et.uniforms.dyeTexelSize, 1 / m, 1 / v);
          gl.uniform1i(et.uniforms.uVelocity, y.read.attach(0)),
            gl.uniform1i(et.uniforms.uSource, g.read.attach(1)),
            gl.uniform1f(et.uniforms.dissipation, e.DENSITY_DISSIPATION),
            U(g.write.fbo),
            g.swap()
        }(.016),
        function (n) {
          e.BLOOM && function (t, n) {
            if (s.length < 2)
              return;
            var r = n;
            gl.disable(gl.BLEND),
              K.bind();
            var i = e.BLOOM_THRESHOLD * e.BLOOM_SOFT_KNEE + 1e-4
              , o = e.BLOOM_THRESHOLD - i
              , a = 2 * i
              , l = .25 / i;
            gl.uniform3f(K.uniforms.curve, o, a, l),
              gl.uniform1f(K.uniforms.threshold, e.BLOOM_THRESHOLD),
              gl.uniform1i(K.uniforms.uTexture, t.attach(0)),
              gl.viewport(0, 0, r.width, r.height),
              U(r.fbo),
              Q.bind();
            for (var u = 0; u < s.length; u++) {
              var h = s[u];
              gl.uniform2f(Q.uniforms.texelSize, 1 / r.width, 1 / r.height),
                gl.uniform1i(Q.uniforms.uTexture, r.attach(0)),
                gl.viewport(0, 0, h.width, h.height),
                U(h.fbo),
                r = h
            }
            gl.blendFunc(gl.ONE, gl.ONE),
              gl.enable(gl.BLEND);
            for (var f = s.length - 2; f >= 0; f--) {
              var d = s[f];
              gl.uniform2f(Q.uniforms.texelSize, 1 / r.width, 1 / r.height),
                gl.uniform1i(Q.uniforms.uTexture, r.attach(0)),
                gl.viewport(0, 0, d.width, d.height),
                U(d.fbo),
                r = d
            }
            gl.disable(gl.BLEND),
              $.bind(),
              gl.uniform2f($.uniforms.texelSize, 1 / r.width, 1 / r.height),
              gl.uniform1i($.uniforms.uTexture, r.attach(0)),
              gl.uniform1f($.uniforms.intensity, e.BLOOM_INTENSITY),
              gl.viewport(0, 0, n.width, n.height),
              U(n.fbo)
          }(g.read, w);
          null != n && e.TRANSPARENT ? gl.disable(gl.BLEND) : (gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA),
            gl.enable(gl.BLEND));
          var r = null == n ? gl.drawingBufferWidth : m
            , i = null == n ? gl.drawingBufferHeight : v;
          if (gl.viewport(0, 0, r, i),
            !e.TRANSPARENT) {
            W.bind();
            var o = e.BACK_COLOR;
            gl.uniform4f(W.uniforms.color, o.r / 255, o.g / 255, o.b / 255, o.a),
              U(n)
          }
          null == n && e.TRANSPARENT && (X.bind(),
            gl.uniform1f(X.uniforms.aspectRatio, t.width / t.height),
            U(null));
          if (e.SHADING) {
            var a = e.BLOOM ? J : Z;
            if (a.bind(),
              gl.uniform2f(a.uniforms.texelSize, 1 / r, 1 / i),
              gl.uniform1i(a.uniforms.uTexture, g.read.attach(0)),
              e.BLOOM) {
              gl.uniform1i(a.uniforms.uBloom, w.attach(1)),
                gl.uniform1i(a.uniforms.uDithering, G.attach(2));
              var l = vt(G, r, i);
              gl.uniform2f(a.uniforms.ditherScale, l.x, l.y)
            }
          } else {
            var u = e.BLOOM ? Y : q;
            if (u.bind(),
              gl.uniform1i(u.uniforms.uTexture, g.read.attach(0)),
              e.BLOOM) {
              gl.uniform1i(u.uniforms.uBloom, w.attach(1)),
                gl.uniform1i(u.uniforms.uDithering, G.attach(2));
              var h = vt(G, r, i);
              gl.uniform2f(u.uniforms.ditherScale, h.x, h.y)
            }
          }
          U(n)
        }(null)
    }
      .bind(this),
    splat: function () {
      o.push(parseInt(20 * Math.random(), 10) + 5)
    }
  }
}

export default class ColorfulCursor {
  _instance = null;
  _frame = null;
  _time = null;
  _frameSeg = -1;
  _fps = 90;
  _playing = false

  constructor({ canvas, fps, BACK_COLOR }) {
    if (!canvas) return;
    this._instance = initCursor(canvas, { BACK_COLOR });
    if (fps) this._fps = fps;
  }

  _start(timestamp = 0) {
    this._frame = window.requestAnimationFrame(this._start.bind(this));

    if (this._time === undefined) this._time = timestamp;

    var e = Math.floor((timestamp - this._time) / (1000 / this._fps));
    if (e > this._frameSeg) {
      this._frameSeg = e;
      this._instance.update();
    }
  }

  play() {
    if (this._instance && !this._playing) {
      this._playing = true;
      this._start();
    }
  }

  pause() {
    if (this._instance && this._playing) {
      window.cancelAnimationFrame(this._frame);
      this._playing = false;
    }
  }
}
