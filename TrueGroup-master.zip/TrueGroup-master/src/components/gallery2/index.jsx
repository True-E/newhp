import React, { useEffect, useRef } from 'react';

import './index.scss';

class MoveBus {
  moveEndHandlers = [];
  moveCompletelyHandlers = [];
  busEl = null;
  containerEl = null;
  moveDistance = 0;
  moveEndDuration = 0;
  moveCompletelyDuration = 0;
  moveCompletelyTid = null;
  speed = 0;
  running = false;
  hasMoveOnce = false;

  constructor({
    busEl,
    containerEl = document.body,
    speed = 100,
    offset = 0
  }) {
    this.speed = speed;
    this.offset = offset;
    this.containerEl = containerEl;
    this.busEl = busEl;
    this.busEl.addEventListener('transitionend', this.transitionendHandler);

    this.reset();
  }

  calcSize() {
    let offset = 0;
    if (!this.hasMoveOnce && this.offset) offset = this.offset;

    const busLength = this.busEl.offsetWidth;
    const containerLength = this.containerEl.offsetWidth;
    this.moveDistance = busLength + containerLength - offset;
    this.moveEndDuration = this.moveDistance / this.speed;
    this.moveCompletelyDuration = (busLength - offset) / this.moveDistance * this.moveEndDuration;
  }

  transitionstartHandler = () => {
    this.moveCompletelyTid = setTimeout(() => {
      this.moveCompletelyHandlers.forEach(handler => handler())
    }, this.moveCompletelyDuration * 1000)
  }

  transitionendHandler = () => {
    this.backToStart();
    this.moveEndHandlers.forEach(handler => handler())
  }

  start() {
    if (this.running) this.backToStart();

    const transformStyle = `translateX(-${this.moveDistance}px)`
    this.busEl.style.transition = `transform linear ${this.moveEndDuration}s`;
    this.busEl.style.transform = transformStyle;
    this.busEl.addEventListener('transitionstart', this.transitionstartHandler);

    this.running = true;
  }

  reset() {
    clearTimeout(this.moveCompletelyTid);
    const transformStyle = `translateX(0)`;
    this.hasMoveOnce = false;
    this.running = false;
    this.busEl.style.transition = 'none';
    this.busEl.style.transform = transformStyle;
    this.calcSize();

    // 初次移动前的偏移
    if (this.offset) {
      this.busEl.style.marginLeft = `-${this.offset}px`;
    }
  }

  backToStart() {
    const transformStyle = `translateX(0)`;
    this.busEl.style.transition = 'none';
    this.busEl.style.transform = transformStyle;
    this.busEl.style.marginLeft = 0;
    this.running = false;

    if (!this.hasMoveOnce && this.offset) {
      this.hasMoveOnce = true;
      this.calcSize()
    } else {
      this.hasMoveOnce = true;
    }
  }

  /**
   * 节点完整从屏幕外移动出来，用于触发下一辆bus移动
   */
  onMoveCompletely(callback) {
    this.moveCompletelyHandlers.push(callback)
  }

  onMoveEnd(callback) {
    this.moveEndHandlers.push(callback)
  }

  destroy() {
    this.busEl.removeEventListener('transitionstart', this.transitionstartHandler);
    this.busEl.removeEventListener('transitionend', this.transitionendHandler);
  }
}

export default ({
  children,
  gap = 0,
  speed,
  repeatCount = 2,
  height = 0,
  start = false,
  onChange
}) => {
  const containerRef = useRef(null);
  const busElRefs = useRef([]);
  const moveBusRefs = useRef(null);

  useEffect(() => {
    if (!moveBusRefs.current) {
      // 确保节点已上屏，能取到宽度
      setTimeout(() => {
        moveBusRefs.current = busElRefs.current.map((busEl, index) => {
          return new MoveBus({
            busEl,
            containerEl: containerRef.current,
            speed,
            offset: index === 0 ? containerRef.current.offsetWidth : 0
          })
        });

        const firstBus = moveBusRefs.current[0];
        const lastBus = moveBusRefs.current.reduce((pre, cur) => {
          if (pre) {
            pre.onMoveCompletely(() => {
              window.requestAnimationFrame(() => cur.start())
            })
          }
          return cur;
        }, null);
        lastBus.onMoveCompletely(() => {
          window.requestAnimationFrame(() => firstBus.start())
        });

        document.addEventListener('visibilitychange', () => {
          if (document.visibilityState === 'visible') {
            moveBusRefs.current.forEach(moveBus => moveBus.reset());
            firstBus.start()
          }
        });

        if (onChange && typeof IntersectionObserver) {
          const intersectionObserver = new IntersectionObserver(
            (entries) => {
              // 如果不可见，就返回
              if (entries[0].intersectionRatio <= 0) {
                const curEl = entries[0].target;
                let nextEl = curEl.nextElementSibling;
                if (!nextEl) {
                  if (curEl.parentElement.nextElementSibling) {
                    nextEl = curEl.parentElement.nextElementSibling.firstElementChild;
                  } else {
                    nextEl = curEl.parentElement.parentElement.firstElementChild.firstElementChild;
                  }
                }
                onChange(nextEl, curEl)
              }
            });
  
          // 开始观察
          busElRefs.current.forEach((item) => {
            [].slice.call(item.children).forEach(el => {
              intersectionObserver.observe(el)
            });
          });

          onChange(busElRefs.current[0].firstElementChild)
        }

        if (start) firstBus.start()
      }, 100);
    } else if (start){
      moveBusRefs.current.forEach(moveBus => moveBus.reset());
      moveBusRefs.current[0].start();
    }

    return () => {
      if (moveBusRefs.current) moveBusRefs.current.forEach(moveBus => moveBus.destroy());
    }
  }, [start]);

  return (
    <div className="gallery" style={{ height: `${height}px` }} ref={containerRef}>
      {
        Array(repeatCount).fill(1).map((_item, index) => (
          <div
            key={index}
            ref={el => busElRefs.current[index] = el}
            className="gallery-bus"
            style={{ paddingRight: `${gap}px` }}
          >
            {children}
          </div>
        ))
      }
    </div>
  )
}