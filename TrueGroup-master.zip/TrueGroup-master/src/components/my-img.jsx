import React, { useLayoutEffect, useRef } from 'react';
import GlobalEmitter from '../utils/global-emitter';

export default (props) => {
  const image = useRef();

  useLayoutEffect(() => {
    GlobalEmitter.emit('addLoadCount')

    if (image.current.complete && !image.current.hasLoad) {
      image.current.hasLoad = true;
      GlobalEmitter.emit('oneLoaded')
    }
  }, [])

  return <img
    {...props}
    ref={image}
    onLoad={() => {
      if (!image.current.hasLoad) {
        image.current.hasLoad = true;
        GlobalEmitter.emit('oneLoaded');
      }
    }}
    onError={() => GlobalEmitter.emit('loadFail')}
  />
}