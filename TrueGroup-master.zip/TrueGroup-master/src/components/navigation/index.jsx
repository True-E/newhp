import React, { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ScrollToPlugin } from "gsap/ScrollToPlugin";

import './index.scss';

gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

export default () => {
  const navList = [
    { title: 'Home', anchorId: 'home' },
    { title: 'Service', href: 'xxx' },
    { title: 'About', href: 'xxx' },
    { title: 'Course', href: 'xxx' },
    { title: 'FAQ', anchorId: 'faq' },
    { title: 'Contact', anchorId: 'contact' },
  ];

  useEffect(() => {
    const links = gsap.utils.toArray('.nav-a[anchor]');
    links.forEach(linkEl => {
      const anchorId = linkEl.getAttribute('anchor');
      const sectionEl = document.getElementById(anchorId);

      if (!anchorId || !sectionEl) return;

      const linkST = ScrollTrigger.create({
        trigger: sectionEl,
        start: 'top top'
      });
      ScrollTrigger.create({
        trigger: sectionEl,
        start: 'top center',
        end: "bottom center",
        onToggle: self => {
          if (self.isActive) {
            links.forEach(el => el.classList.remove('active'));
            linkEl.classList.add('active');
          } else {
            linkEl.classList.remove('active');
          }
        }
      });
      linkEl.addEventListener('click', e => {
        e.preventDefault();
        gsap.to(window, { duration: 1, scrollTo: linkST.start, overwrite: 'auto' });
      });
    });
  }, []);

  return <nav className="navigation">
    {
      navList.map(({ title, href, anchorId }, index) => (
        <a
          key={index}
          href={href}
          anchor={anchorId}
          target="_blank"
          className="nav-a"
        >
          <div className="nav-bg-hover" />
          <div className="nav-text">{title}</div>
        </a>
      ))
    }
  </nav>
}