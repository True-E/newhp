import React, { useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import QmRiversideMap from './sections/qm-riverside-map';
import Astronaut from './sections/astronaut';
import Meeting from './sections/meeting';
import Plant from './sections/plant';
import Honor from './sections/honor';
import Certificates from './sections/certificates';
import Course from './sections/course';
import Services from './sections/services';
import Faq from './sections/faq';
import Contact from './sections/contact';
import Loading from './sections/loading';
import ColorfulCursor from '../../components/colorful-cursor';
import Navigation from '../../components/navigation';
import { isMobile } from '../../utils/device';

import './index.scss';

function Page() {
  const colorfulCursorCanvas = useRef(null);

  useEffect(() => {
    // 初始化彩色鼠标
    const colorfulCursor = new ColorfulCursor({
      canvas: colorfulCursorCanvas.current,
      BACK_COLOR: { r: 0, g: 0, b: 0, a: 0 }
    });

    colorfulCursor.play();

    // ScrollTrigger.create({
    //   trigger: '#cursorTag',
    //   start: 'top top',
    //   onEnter: () => colorfulCursor.play(),
    //   onEnterBack: () => colorfulCursor.pause(),
    // });
  }, []);


  return (
    <div className={`root ${isMobile ? 'mobile-mode' : ''}`}>
      <Loading />
      <Navigation />

      <div id="home">
        <QmRiversideMap />
        <Astronaut />
        <Meeting />
        <Plant />
        <Honor />
        <Certificates />
        <Course />
        <Services />
      </div>

      <Faq />
      <Contact />

      <canvas ref={colorfulCursorCanvas} className='colorful-cursor'></canvas>
    </div>
  )
}

createRoot(document.getElementById('page')).render(<Page />);