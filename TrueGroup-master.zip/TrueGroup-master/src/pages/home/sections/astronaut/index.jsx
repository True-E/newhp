import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { isMobile } from '../../../../utils/device'
import MyImg from "../../../../components/my-img";

import './index.scss';

import mainImg from './assets/main.png';
import skyImg from './assets/sky.png';
import helmetImg from './assets/helmet.png';
import mainMobileImg from './assets/main_mobile.png';
import skyMobileImg from './assets/sky_mobile.png';
import helmetMobileImg from './assets/helmet_mobile.png';

const HELMET_X = isMobile ? 500 : 568; // 头盔在背景图中的 x 轴
const HELMET_Y = isMobile ? 630 : 360; // 头盔在背景图中的 y 轴
const BG_WIDTH = isMobile ? 1228 : 2010; // 背景图宽度
const BG_HEIGHT = isMobile ? 2388 : 1336; // 背景图高度

gsap.registerPlugin(ScrollTrigger);

const SECTION_HEIGHT = 1500;

export default () => {
  const sectionRef = useRef(null);
  const sectionFixedContentRef = useRef(null);

  useEffect(() => {
    // 固定画布
    ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top top',
      end: 'bottom top',
      scrub: true,
      toggleClass: "active",
    });

    // 背景出场
    const bgInTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top bottom',
        end: 'top top',
        scrub: true,
      },
    });
    bgInTimeline.to(sectionRef.current, {
      duration: 5,
      opacity: 1,
    }).to('.bg-sky', {
      duration: 1,
      opacity: 1,
      ease: 'power1.in'
    });

    // 中间动画
    const centerTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top top',
        end: 'bottom bottom',
        scrub: true,
      },
    })
    const sloganEls = gsap.utils.toArray('.slogan-item');
    sloganEls.forEach(sloganEl => {
      centerTimeline.to(sloganEl, {
        x: '-100%',
        ease: 'power1.inOut'
      })
    });


    // 背景退场
    const bgRenderWidth = Math.max(window.innerHeight * (BG_WIDTH / BG_HEIGHT), window.innerWidth);
    const bgRenderHeight = Math.max(window.innerWidth * (BG_HEIGHT / BG_WIDTH), window.innerHeight);
    const helmetX = bgRenderWidth * HELMET_X / BG_WIDTH;
    const helmetY = bgRenderHeight * HELMET_Y / BG_HEIGHT;

    const bgOutTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'bottom bottom',
        end: 'bottom top',
        scrub: true,
      },
    })
    bgOutTimeline.to('.bg-wrapper', {
      x: window.innerWidth / 2 - helmetX,
      y: window.innerHeight / 2 - helmetY,
      scale: 2,
      transformOrigin: `${helmetX / window.innerWidth * 100}% ${helmetY / window.innerHeight * 100}%`,
      ease: 'power1.inOut',
      duration: 3
    })

    if (isMobile) {
      bgOutTimeline
        .to('.slogan-wrapper', {
          x: '100%',
          duration: 1
        }, '<')
        .to('.bg-helmet', {
          opacity: 0,
          ease: 'power1.inOut',
          duration: 1
        })
        .to('.bg-wrapper', {
          scale: 4,
          ease: 'power1.inOut',
          duration: 1
        }, '<')
        .to('.bg-wrapper', {
          scale: 8,
          ease: 'power1.inOut',
          duration: 1
        })
        .to(sectionFixedContentRef.current, {
          opacity: 0,
          ease: 'power1.inOut',
          duration: 1
        }, '<')
    } else {
      bgOutTimeline
        .to('.bg-helmet', {
          opacity: 0,
          ease: 'power1.inOut',
          duration: 1
        })
        .to('.slogan-wrapper', {
          x: '100%',
          duration: 1
        }, '<')
        .to('.bg-wrapper', {
          scale: 12,
          ease: 'power1.inOut',
          duration: 1
        }, '<')
        .to('.bg-wrapper', {
          scale: 20,
          ease: 'power1.inOut',
          duration: 1
        })
        
        .to(sectionFixedContentRef.current, {
          opacity: 0,
          ease: 'power1.inOut',
          duration: 1
        }, '<')
    }
  }, []);

  return (
    <div
      className="section astronaut-section"
      style={{ height: `${SECTION_HEIGHT}px` }}
      ref={sectionRef}
    >
      <div
        className="section-fixed-content"
        ref={sectionFixedContentRef}>

        <div className="bg-wrapper">
          {/* 主体 */}
          <div
            style={{ backgroundImage: `url(${isMobile ? mainMobileImg : mainImg})` }}
            className="bg-img bg-main" />
          <MyImg
            src={isMobile ? mainMobileImg : mainImg}
            className="hidden-img"
          />

          {/* 头盔 */}
          <div
            style={{ backgroundImage: `url(${isMobile ? helmetMobileImg : helmetImg})` }}
            className="bg-img bg-helmet" />
          <MyImg
            src={isMobile ? mainMobileImg : mainImg}
            className="hidden-img"
          />

          {/* 天空 */}
          <div
            style={{ backgroundImage: `url(${isMobile ? skyMobileImg : skyImg})` }}
            className="bg-img bg-sky" />
          <MyImg
            src={isMobile ? mainMobileImg : mainImg}
            className="hidden-img"
          />
        </div>

        {
          isMobile
            ? <div className="slogan-wrapper">
              <div className="slogan-item"><span className="highlight">P</span>ROFESSIL</div>
              <div className="slogan-item">ONAL</div>

              <div className="slogan-item"><span className="highlight">P</span>ASSIONA</div>
              <div className="slogan-item">TE</div>

              <div className="slogan-item"><span className="highlight">R</span>ESULT-</div>

              <div className="slogan-item"><span className="highlight">O</span>RIENTED</div>

              <div className="slogan-item"><span className="highlight">W</span>ITH</div>

              <div className="slogan-item"><span className="highlight">T</span>RUE-E</div>

              <div className="slogan-item"><span className="highlight">T</span>HERE</div>

              <div className="slogan-item"><span className="highlight">W</span>ILL <span className="highlight">B</span>E</div>

              <div className="slogan-item"><span className="highlight">G</span>REAT</div>

              <div className="slogan-item"><span className="highlight">T</span>RAFFIC</div>

              <div className="slogan-item"><span className="highlight">G</span>REAT</div>

              <div className="slogan-item"><span className="highlight">S</span>EO</div>

              <div className="slogan-item"><span className="highlight">G</span>REAT</div>

              <div className="slogan-item"><span className="highlight">D</span>ESIGN</div>
            </div>
            : <div className="slogan-wrapper">
              <div className="slogan-item"><span className="highlight">P</span>ROFESSIONAL</div>

              <div className="slogan-item"><span className="highlight">P</span>ASSIONATE</div>

              <div className="slogan-item"><span className="highlight">R</span>ESULT-</div>

              <div className="slogan-item"><span className="highlight">O</span>RIENTED</div>

              <div className="slogan-item"><span className="highlight">W</span>ITH <span className="highlight">T</span>RUE-E</div>

              <div className="slogan-item"><span className="highlight">T</span>HERE <span className="highlight">W</span>ILL <span className="highlight">B</span>E</div>

              <div className="slogan-item"><span className="highlight">G</span>REAT <span className="highlight">T</span>RAFFIC</div>

              <div className="slogan-item"><span className="highlight">G</span>REAT <span className="highlight">S</span>EO</div>

              <div className="slogan-item"><span className="highlight">G</span>REAT <span className="highlight">D</span>ESIGN</div>
            </div>}
      </div>
    </div>
  )
}