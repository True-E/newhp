import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Gallery2 from "../../../../components/gallery2";
import MyImg from "../../../../components/my-img";
import { isMobile } from "../../../../utils/device";

import './index.scss';

gsap.registerPlugin(ScrollTrigger);

const CERTIFICATE_LIST = [
  {
    img: require('./assets/p1.jpg')
  },
  {
    img: require('./assets/p2.jpg')
  },
  {
    img: require('./assets/p3.jpg')
  },
  {
    img: require('./assets/p4.jpg')
  },
  {
    img: require('./assets/p5.jpg')
  },
  {
    img: require('./assets/p6.jpg')
  },
]

export default () => {
  const sectionRef = useRef(null);
  const sectionFixedContentRef = useRef(null);
  const [galleryStart, setGalleryStart] = useState(false);

  useEffect(() => {
    // 章节状态切换
    !isMobile && ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top top',
      end: 'bottom top',
      scrub: true,
      toggleClass: "active",
    });

    // 固定内容退场
    if (isMobile) {
      gsap.to(sectionFixedContentRef.current, {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'bottom bottom',
          end: 'bottom center',
          scrub: true,
        },
        opacity: 0
      });
    } else {
      gsap.to(sectionFixedContentRef.current, {
        scrollTrigger: {
          trigger: '.certificates-gallery',
          start: 'top center',
          end: 'top top',
          scrub: true,
        },
        opacity: 0
      });
    }

    // 描述渐隐
    !isMobile && gsap.to('.certificates-desc', {
      scrollTrigger: {
        trigger: '.certificates-desc',
        start: 'top 35%',
        end: "bottom top",
        scrub: true,
      },
      opacity: 0
    })

    // 证书画廊
    !isMobile && ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top top',
      end: "bottom top",
      scrub: true,
      onEnter: () => setGalleryStart(true),
      onEnterBack: () => setGalleryStart(true),
      onLeaveBack: () => setGalleryStart(false),
      onLeave: () => setGalleryStart(false),
    });
  }, []);

  return (
    <div
      className="section certificates-section"
      ref={sectionRef}
    >
      <div
        className="section-fixed-content"
        ref={sectionFixedContentRef}>
        {
          !isMobile && <div className="section-title">OUR CERTIFICATES</div>
        }
      </div>

      {
        isMobile && <div className="section-title">OUR <br />CERTIFICATES</div>
      }

      <div className="desc-wrapper in-center">
        <div className="certificates-desc">
          True-E Marketing is a top-rated, award-winning full-service marketing agency, based in Toronto and serving clients across North America.
        </div>

        {
          isMobile && <div className="certificates-list">
            {
              CERTIFICATE_LIST.map(({ img }, index) => (
                <MyImg
                  className="img"
                  key={index}
                  src={img}
                />
              ))
            }
          </div>
        }
      </div>

      {
        !isMobile && <div className="certificates-content">
          <div className="certificates-gallery-stage">
            <div className="certificates-gallery">
              <Gallery2
                height={300}
                start={galleryStart}>
                {
                  CERTIFICATE_LIST.map(({ img }, index) => (
                    <MyImg
                      className="img"
                      key={index}
                      src={img}
                    />
                  ))
                }
              </Gallery2>
            </div>
          </div>
        </div>
      }
    </div>
  )
}