import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Gallery from "../../../../components/gallery";
import MyImg from "../../../../components/my-img";
import { isMobile } from "../../../../utils/device";

import './index.scss';
import crystalBallImg from './assets/crystal_ball.png';
import qrCodeImg from './assets/qr_code.png';
import mailBlackImg from './assets/mail_b.svg';
import mailWhiteImg from './assets/mail_w.svg';

gsap.registerPlugin(ScrollTrigger);

const EMAIL = 'hello@true-e.ca';
const FOOTER_LIST = [
  {
    flex: 3,
    subList: [
      {
        title: 'Home',
      },
      {
        title: 'About us',
        href: 'xxx'
      },
      {
        title: 'Courses',
        href: 'xxx'
      },
      {
        title: 'follow us',
        href: 'xxx'
      }
    ],
  },
  {
    flex: 6,
    subList: [
      {
        title: 'Our Service:',
      },
      {
        title: 'Website Design&development',
        href: 'https://www.trueegroup.com/website-design'
      },
      {
        title: 'Social Media Management',
        href: 'https://www.trueegroup.com/social-media'
      },
      {
        title: 'Google SEO',
        href: 'https://www.trueegroup.com/seo-services'
      },
      {
        title: 'Google Advertising',
        href: 'https://www.trueegroup.com/ppc-services'
      },
      {
        title: 'Overseas Press Release',
        href: 'https://www.trueegroup.com/press-release'
      }
    ],
  },
  {
    flex: 6,
    subList: [
      {
        title: 'Contact Us:',
      },
      {
        title: `15 Allstate Parkway, Suite 600 Markham, ${isMobile ? '' : 'ON L3R 5B4'}`,
      },
      {
        title: isMobile ? 'ON L3R 5B4' : ''
      },
      {
        title: EMAIL,
      },
      {
        title: 'Tuesday to Saturday',
      },
      {
        title: '12pm~6pm(EST)',
      }
    ]
  }
];

export default () => {
  const [galleryPaused, setGalleryPaused] = useState(true);

  useEffect(() => {
    // 画廊
    ScrollTrigger.create({
      trigger: '.contact-gallery',
      start: 'top bottom',
      end: "bottom top",
      onEnter: () => setGalleryPaused(false),
      onEnterBack: () => setGalleryPaused(false),
      onLeaveBack: () => setGalleryPaused(true),
      onLeave: () => setGalleryPaused(true)
    });
  }, []);

  return (
    <div id="contact" className="section contact-section">
      <div className="contact-gallery">
        <Gallery
          itemSelector=".contact-gallery-item"
          paused={galleryPaused}
        >
          <div className="contact-gallery-item">
            Talk to us — True-E.ca — Talk to us — True-E.ca —
          </div>
        </Gallery>
      </div>

      <a className="email" href={`mailto:${EMAIL}`}>
        <div className="hover-bg"></div>
        <MyImg src={mailBlackImg} className="mail-img mail-b-img" alt="" />
        <MyImg src={mailWhiteImg} className="mail-img mail-w-img" alt="" />
      </a>

      <div className="contact-content in-center">
        <MyImg className="crystal-ball" src={crystalBallImg} alt="" />

        <div className="footer">
          {
            FOOTER_LIST.map((column, cIndex) => (
              <div key={cIndex} style={{ flex: column.flex }} className="footer-column">
                {
                  column.subList.map(({ href, title }, index) => {
                    if (!title) return null
                    return href ? (
                      <a
                        href={href}
                        key={index}
                        target="_blank"
                        className="footer-item">{title}
                      </a>
                    ) : (
                      <div key={index} className="footer-item">{title}
                      </div>
                    )
                  })
                }
              </div>
            ))
          }
          <div className="footer-column" style={{ flex: 3 }}>
            <MyImg className="qr-code" src={qrCodeImg} alt="" />
          </div>
        </div>
      </div>
    </div>
  )
}