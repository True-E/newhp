import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { isMobile } from "../../../../utils/device";
import MyImg from "../../../../components/my-img";


import './index.scss';
import logListImg from './assets/logo_list.png';

gsap.registerPlugin(ScrollTrigger);

export default () => {
  useEffect(() => {
  }, []);

  return (
    <div className="section course-section">
      <div className="section-title">OUR {isMobile && <br />}COURSES</div>

      <div className="course-content in-center">
        <div className="course-title">
          Digital Marketing
          <br />Courses
        </div>

        <MyImg src={logListImg} className="course-logo" />

        <div className="course-desc">
          Course content: TikTok, Google SEO, Youtube, Facebook, Instagram contents and advertising, Wordpress, Shopify
          <br />Class hours: 50 hours – 2-4 hours per week
        </div>
      </div>
    </div>
  )
}