import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { isMobile } from "../../../../utils/device";

import './index.scss';
import { FAQ_LIST } from './static';
import patternImg from '../meeting/assets/pattern.jpg';

gsap.registerPlugin(ScrollTrigger);

export default () => {
  const [activeIndex, setActiveIndex] = useState();
  const sectionRef = useRef(null);
  const sectionFixedContentRef = useRef(null);
  const answerListRef = useRef([]);

  useEffect(() => {
    /** 出场 */
    !isMobile && ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top top',
      end: 'bottom top',
      scrub: 1,
      toggleClass: "active",
    });

    /** 退场 */
    !isMobile && gsap.to(sectionFixedContentRef.current, {
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'bottom center',
        end: 'bottom top',
        scrub: 1,
      },
      opacity: 0
    });
  }, [activeIndex]);

  return (
    <div
      id="faq"
      className="section faq-section"
      ref={sectionRef}
    >
      <div
        className="faq-section-bg"
        style={{ backgroundImage: `url(${patternImg})` }}
      ></div>

      {
        !isMobile && <div
          className="section-fixed-content"
          ref={sectionFixedContentRef}>
          <div className="section-title">FAQ</div>
        </div>
      }

      {
        isMobile && <div className="section-title">FAQ</div>
      }

      <div className="faq-content">
        {
          FAQ_LIST.map(({ q, a }, index) => (
            <div
              className={`faq-item ${activeIndex === index ? 'active' : ''}`}
              key={index}
              onClick={() => setActiveIndex(index === activeIndex ? undefined : index)}
            >
              <div className='bg' />
              <div className="inner">
                <div className="question">
                  <div className="question-index">{index < 9 ? `0${index + 1}` : index + 1}.</div>
                  <div className="question-text">{q}</div>
                </div>
                <div
                  className="answer"
                  style={
                    activeIndex === index ? {
                      height: (answerListRef.current[index] && answerListRef.current[index].offsetHeight || 0) + 'px'
                    } : {}
                  }
                >
                  <div className="answer-inner" ref={el => answerListRef.current[index] = el} dangerouslySetInnerHTML={{ __html: a }}></div>
                </div>
              </div>

            </div>
          ))
        }
      </div>
    </div>
  )
}