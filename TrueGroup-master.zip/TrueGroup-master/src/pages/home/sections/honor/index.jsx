import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { isMobile } from "../../../../utils/device";
import MyImg from "../../../../components/my-img";

import './index.scss';
import cbrbImg from './assets/cbrb.png';
import threeBestImg from './assets/tree-best.png';
import consumerChoiceImg from './assets/consumer-choice.png';
import designrushImg from './assets/designrush.png';

gsap.registerPlugin(ScrollTrigger);

const HONOR_LIST = [
  {
    title: [
      '2022',
      'BEST CBRB',
      'BUSINESS IN',
      'CANADA VERIFIED'
    ],
    img: cbrbImg
  },
  {
    title: [
      '2022',
      'BEST BUSINESS',
      'THREE BEST RATED',
    ],
    img: threeBestImg
  },
  {
    title: [
      '2021',
      'CONSUMER',
      'CHOICE AWARD',
      'BUSINESS EXCELLENCE'
    ],
    img: consumerChoiceImg
  },
  {
    title: ['2021', 'DESIGN RUSH', 'ACCREDITED AGENCY'],
    img: designrushImg
  },

]

export default () => {
  const sectionRef = useRef(null);
  const sectionFixedContentRef = useRef(null);

  useEffect(() => {
    if (!isMobile) {
      /** 出场 */
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top top',
        end: 'bottom top',
        scrub: true,
        toggleClass: "active",
      });

      /** 退场 */
      gsap.to(sectionFixedContentRef.current, {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'bottom bottom',
          end: 'bottom center',
          scrub: true,
        },
        opacity: 0
      });
    }

    // 荣誉表
    const honorEls = gsap.utils.toArray('.honor-item');
    honorEls.forEach(honorEl => {
      // 高亮
      ScrollTrigger.create({
        trigger: honorEl,
        start: 'top center',
        end: "bottom center",
        toggleClass: 'active'
      });

      // 渐隐
      !isMobile && gsap.to(honorEl, {
        scrollTrigger: {
          trigger: honorEl,
          start: 'top 20%',
          end: 'bottom top',
          scrub: true,
        },
        opacity: 0
      })
    });
  }, []);

  return (
    <div
      className="section honor-section"
      ref={sectionRef}
    >
      <div className="section-fixed-content" ref={sectionFixedContentRef}>
        {
          !isMobile && <div className="section-title">OUR HONORS</div>
        }
      </div>

      {
        isMobile && <div className="section-title">OUR <br />HONORS</div>
      }

      <div className="honor-list in-center">
        {
          HONOR_LIST.map(({ title, img }, index) => (
            <div key={index} className="honor-item">
              <div className="title">
                {
                  title.map((item, index) => (
                    <div key={index} className="title-text">{item}</div>
                  ))
                }
              </div>
              <MyImg className="img" src={img} />
            </div>
          ))
        }
      </div>
    </div>
  )
}