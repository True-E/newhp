import React, { useLayoutEffect, useState, useRef } from 'react';
import GlobalEmitter from '../../../../utils/global-emitter';
import { ScrollTrigger } from "gsap/ScrollTrigger";


import './index.scss';

import logImg from './assets/logo.jpg';


export default () => {
  const [fail, setFail] = useState(false);
  const [refreshTag, setRefreshTag] = useState(Date.now());
  const loadedCountRef = useRef(0);
  const needLoadCountRef = useRef(Infinity);
  const loadedCount = loadedCountRef.current;
  const needLoadCount = needLoadCountRef.current;
  const ready = loadedCount === needLoadCount;

  if (ready) {
    document.body.style.overflow = ready ? 'auto' : 'hidden';
    ScrollTrigger.refresh(true);
  }

  useLayoutEffect(() => {
    GlobalEmitter.on('addLoadCount', (num = 1) => {
      if (needLoadCountRef.current === Infinity) {
        needLoadCountRef.current = 0;
      }
      needLoadCountRef.current += num;
      // console.log('addLoadCount', needLoadCountRef.current);
      setRefreshTag(Date.now());
    });
    GlobalEmitter.on('oneLoaded', () => {
      loadedCountRef.current += 1;
      // console.log('oneLoaded', loadedCountRef.current);
      setRefreshTag(Date.now());
    });
    GlobalEmitter.on('loadFail', () => {
      setFail(true)
    });
  }, []);

  return (
    <div
      className={`loading-section ${ready ? 'ready' : ''} ${fail ? 'fail' : ''}`}
      timestamp={refreshTag}
    >
      <img src={logImg} className="logo" />

      <div className="loading">
        <div
          className="loading-progress"
          style={{
            width: `${loadedCount / needLoadCount * 100}%`
          }}></div>
      </div>

      <div className='tip'>
        {fail ? 'LOADING FAIL, PLEASE REFRESH!' : 'LOADING...'}</div>
    </div>
  )
}