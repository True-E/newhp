import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { isMobile } from "../../../../utils/device";
import GlobalEmitter from '../../../../utils/global-emitter';
import MyImg from "../../../../components/my-img";

import './index.scss';
import vinylRecordImg from './assets/vinyl_record.png';
import meetingImg from './assets/meeting.png';
import patternImg from './assets/pattern.jpg';
import topTextImg from './assets/top_text.png';
import topTextMobileImg from './assets/top_text_mobile.png';
import leftTextImg from './assets/left_text.png';
import tagLImg from './assets/tag_l.png';
import tagRImg from './assets/tag_r.png';
import meetingVideo from './assets/meeting.mp4';

gsap.registerPlugin(ScrollTrigger);

const SECTION_HEIGHT = 3000;

export default () => {
  const sectionRef = useRef(null);
  const sectionFixedContentRef = useRef(null);
  const videoRef = useRef(null);

  useEffect(() => {
    // 视频加入loading计数
    GlobalEmitter.emit('addLoadCount')

    // 切换状态
    ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top bottom',
      end: 'bottom top',
      scrub: true,
      toggleClass: "active",
    });

    // 与上一页过渡动画
    const transTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top center',
        end: 'top top',
        scrub: true,
      },
      onComplete: () => {
        videoRef.current.play()
      }
    });
    transTimeline.fromTo('.section-fixed-content-meeting', {
      scale: 4,
    }, {
      scale: 1
    })

    // 出场动画
    const inTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top top',
        end: 'bottom bottom',
        scrub: true,
      }
    });
    inTimeline
      .to('.record-cover', { // 推开唱片封面
        x: isMobile ? 0 : '-100%',
        y: isMobile ? '-100%' : 0,
        duration: 3,
        delay: 1,
        ease: 'power1.inOut',
      })
      .to('.vinyl-record', { // 推开唱片封面同时胶片也往右位移，手机中是旋转
        x: isMobile ? 0 : '20%',
        rotation: isMobile ? 180 : 0,
        duration: 3,
        ease: 'power1.inOut',
      }, '<')
      .to('.vinyl-record', { // 唱片移到左边并放大
        x: -window.innerWidth / 2 * (isMobile ? 1.2 : 0.8),
        scale: isMobile ? 1 : 2.5,
        rotation: isMobile ? (180 + 60) : 0,
        ease: 'power2.out',
        duration: 1
      })
      .to('.vinyl-record', { // 唱片旋转
        delay: 1,
        rotation: 180 + 60 + 360,
        duration: 6
      });

    /** 退场动画 */
    const outTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'bottom bottom',
        end: 'bottom top',
        scrub: true
      }
    });

    outTimeline.to('.vinyl-record', { // 唱片移动到中间，并缩放至和星球一样大
      x: 0,
      scale: isMobile ? (window.innerWidth / window.innerHeight * 0.9) : 0.9,
      duration: 1
    }).to('.vinyl-record', { // 唱片渐隐
      opacity: 0,
      duration: 1
    });

    // 适配 safari
    videoRef.current.load();
    // 适配微信
    document.addEventListener("WeixinJSBridgeReady", () => {
      videoRef.current.load();
    })
  }, []);

  function onCanPlay() {
    if (videoRef.current.hasLoaded) return;
    videoRef.current.hasLoaded = true;
    GlobalEmitter.emit('oneLoaded');
  }

  return (
    <div
      className="section meeting-section"
      ref={sectionRef}
      style={{ height: `${SECTION_HEIGHT}px` }}>
      <div className="section-fixed-content section-fixed-content-meeting" ref={sectionFixedContentRef}>
        {/* 唱片封面 */}
        <div
          className="record-cover"
          style={{ backgroundImage: `url(${patternImg})` }}
        >
          <MyImg src={patternImg} className="hidden-img" />
          <MyImg src={isMobile ? topTextMobileImg : topTextImg} className="top-text" alt="" />

          <div className="container-d1">
            {!isMobile && <MyImg src={leftTextImg} className="left-text" alt="" />}

            <div className="container-d2">
              <div className="video-wrapper">
                <MyImg className="video-tag-l" src={tagLImg} alt="" />
                <MyImg className="video-tag-r" src={tagRImg} alt="" />
                <MyImg src={meetingImg} className="hidden-img" />
                <video
                  ref={videoRef}
                  className="video"
                  playsInline
                  x5-playsinline="true"
                  webkit-playsinline="true"
                  muted
                  // 如果video不在屏幕中，chrome下不会触发autoplay
                  // autoPlay
                  onCanPlay={onCanPlay}
                  poster={meetingImg}
                  src={meetingVideo} />
              </div>

              {
                !isMobile &&
                <div className="desc">
                  Our team consists of a group of people who love the Internet, learning and innovation. We are one of the few digital marketing companies that provides free digital marketing courses. We have about 10,000 students across Canada, the United States, China, Australia, and Europe.
                  <br />We help our customers become the best players in their respective industries with the latest marketing technologies.
                  <br />Passion keeps us focused.
                </div>
              }
            </div>
          </div>

          {
            isMobile &&
            <div className="container-d3">
              <MyImg src={leftTextImg} className="left-text" alt="" />
              <div className="desc">
                Our team consists of a group of people who love the Internet, learning and innovation. We are one of the few digital marketing companies that provides free digital marketing courses. We have about 10,000 students across Canada, the United States, China, Australia, and Europe.
                <br />We help our customers become the best players in their respective industries with the latest marketing technologies.
                <br />Passion keeps us focused.
              </div>
            </div>
          }
        </div>

        {/* 黑胶唱片 */}
        <div className="vinyl-record">
          <MyImg className="vinyl-record-img" src={vinylRecordImg} alt="" />
        </div>
      </div>

      <div className="record-poster-scroll-tag"></div>
      <div className="vinyl-record-scroll-tag"></div>
    </div >
  )
}

function trackDirection(value) {
  typeof (value) !== "object" && (value = { onUpdate: value });
  let prevTime = 0,
    prevReversed = false,
    anim = value.eventCallback ? value : value.animation,
    onUpdate = value.onUpdate,
    onToggle = value.onToggle;
  return anim ? anim.eventCallback("onUpdate", trackDirection({ onUpdate: onUpdate, onToggle: onToggle })) : function () {
    let time = this.totalTime(),
      reversed = time < prevTime;
    this.direction = reversed ? -1 : 1;
    if (reversed !== prevReversed) {
      onToggle && onToggle.call(this, this.direction);
      prevReversed = reversed;
    }
    prevTime = time;
    onUpdate && onUpdate.call(this, this.direction);
  };
}