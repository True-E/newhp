import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import GlobalEmitter from '../../../../utils/global-emitter';

import './index.scss';

import plantVideo from './assets/plant.mp4';
import { isMobile } from '../../../../utils/device';

gsap.registerPlugin(ScrollTrigger);


export default () => {
  const sectionRef = useRef(null);
  const videoRef = useRef(null);

  useEffect(() => {
    // 视频加入loading计数
    GlobalEmitter.emit('addLoadCount')

    // plant visible
    ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top bottom',
      end: 'top center',
      scrub: true,
      onEnter: () => {
        videoRef.current.classList.add('visible');
      },
      onEnterBack: () => {
        videoRef.current.classList.remove('visible');
      },
      onLeave: () => {
        videoRef.current.classList.add('visible');
      },
      onLeaveBack: () => {
        videoRef.current.classList.remove('visible');
      }
    });

    // plant video play
    ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top center',
      end: '+=1',
      once: true,
      scrub: true,
      onEnter: () => {
        videoRef.current.play();
      }
    });

    // 滚动到 our designs 时，星球消失
    ScrollTrigger.create({
      trigger: '.services-section',
      start: isMobile ? 'top center' : 'top bottom',
      end: '+=1',
      scrub: true,
      onEnter: () => {
        videoRef.current.classList.remove('visible');
      },
      onEnterBack: () => {
        videoRef.current.classList.add('visible');
      }
    });

    // 适配 safari
    videoRef.current.load();
    // 适配微信
    document.addEventListener("WeixinJSBridgeReady", () => {
      videoRef.current.load();
    })
  }, []);

  function onCanPlay() {
    if (videoRef.current.hasLoaded) return;
    videoRef.current.hasLoaded = true;
    GlobalEmitter.emit('oneLoaded');
  }

  return (
    <div
      className="plant-section"
      ref={sectionRef}
    >
      <video
        ref={videoRef}
        className="plant-video"
        playsInline
        x5-playsinline="true"
        webkit-playsinline="true"
        muted
        onCanPlay={onCanPlay}
        src={plantVideo} />
    </div>
  )
}