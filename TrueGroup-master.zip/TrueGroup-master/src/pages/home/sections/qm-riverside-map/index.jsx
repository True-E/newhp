import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { isMobile } from "../../../../utils/device";
import MyImg from "../../../../components/my-img";

import './index.scss';
import bgImg from './assets/bg.jpg';
import bigLetterImg from './assets/big_letter.png';
import smallLetterImg from './assets/small_letter.png';
import fixedSmallLetterImg from './assets/fixed_small_letter.png';
import bgMobileImg from './assets/bg_mobile.jpg';
import bigLetterMobileImg from './assets/big_letter_mobile.png';
import smallLetterMobileImg from './assets/small_letter_mobile.png';
import fixedSmallLetterMobileImg from './assets/fixed_small_letter_mobile.png';

gsap.registerPlugin(ScrollTrigger);

export default () => {
  const sectionRef = useRef(null);
  const sectionFixedContentRef = useRef(null);

  useEffect(() => {
    // 切换状态
    ScrollTrigger.create({
      trigger: sectionRef.current,
      end: 'bottom top',
      scrub: true,
      toggleClass: "active",
    });

    // 视差滚动
    const parallaxTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top top',
        end: 'bottom top',
        scrub: true
      },
    });
    parallaxTimeline.to('.parallax-item', {
      y: (i, target) => -sectionRef.current.offsetHeight * target.dataset.speed,
    }).to('.riverside-bg', {
      y: '-10vh',
    }, '<');

    // 退场动画
    gsap.to('.section-fixed-content-inner', {
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'bottom bottom',
        end: 'bottom top',
        scrub: true,
        ease: 'power1.in',
      },
      opacity: 0
    })
  }, []);

  return (
    <div
      className="section riverside-section active"
      ref={sectionRef}
    >
      <div
        className="section-fixed-content"
        ref={sectionFixedContentRef}>
        <div className="section-fixed-content-inner">
          <div className="riverside-bg" style={{ backgroundImage: `url(${isMobile ? bgMobileImg : bgImg})` }}></div>
          <MyImg
            src={isMobile ? bgMobileImg : bgImg}
            className="hidden-img"
          />

          {/* 居中小贴图+文字 */}
          <div className="center-fixed">
            <div className="riverside-bg" style={{ backgroundImage: `url(${isMobile ? bgMobileImg : bgImg})` }}></div>

            <MyImg src={isMobile ? fixedSmallLetterMobileImg : fixedSmallLetterImg} className="small-letter-img" />
          </div>

          {/* 大文字 */}
          <div className="parallax-item parallax-item-with-margin" data-speed=".65">
            <MyImg
              src={isMobile ? bigLetterMobileImg : bigLetterImg}
              className="letter-img" />
          </div>

          {/* 小文字 */}
          <div className="parallax-item" data-speed=".3">
            <MyImg src={isMobile ? smallLetterMobileImg : smallLetterImg} className="letter-img" />
          </div>
        </div>
      </div>

      <div className="in-center">
        {/* 占位用 */}
        <img className="placeholder-img" src={isMobile ? bigLetterMobileImg : bigLetterImg} />
      </div>
    </div>
  )
}