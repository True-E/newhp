import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Gallery2 from "../../../../components/gallery2";
import MyImg from "../../../../components/my-img";
import { isMobile } from "../../../../utils/device";

import './index.scss';

gsap.registerPlugin(ScrollTrigger);

const DEMO_LIST = [
  {
    img: require('./assets/p1.jpg')
  },
  {
    img: require('./assets/p2.jpg')
  },
  {
    img: require('./assets/p3.jpg')
  },
  {
    img: require('./assets/p4.jpg')
  },
]

export default () => {
  const sectionRef = useRef(null);
  const sectionFixedContentRef = useRef(null);
  const [galleryStart, setGalleryStart] = useState(false);

  useEffect(() => {
    if (isMobile) return;

    /** 出场 */
    ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top top',
      end: 'bottom top',
      scrub: 1,
      toggleClass: "active",
    });

    /** 退场 */
    gsap.to(sectionFixedContentRef.current, {
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'bottom bottom',
        end: 'bottom top',
        scrub: true,
      },
      opacity: 0
    });

    // 画廊
    ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top bottom',
      end: 'bottom top',
      scrub: true,
      onEnter: () => setGalleryStart(true),
      onEnterBack: () => setGalleryStart(true),
      onLeaveBack: () => setGalleryStart(false),
      onLeave: () => setGalleryStart(false),
      onEnter: () => {
        setGalleryStart(true)
      }
    });

    // 描述视差位移
    gsap.to('.services-desc', {
      scrollTrigger: {
        trigger: '.services-gallery-stage',
        start: 'center bottom',
        end: "center top",
        scrub: true,
      },
      y: -100
    })
  }, []);

  if (isMobile) {
    return (
      <div
        className="section services-section"
        ref={sectionRef}
      >
        <div className="section-title">OUR<br />DESIGNS</div>

        <div className="services-desc">
          UX Strategy
          <br />UI Design
          <br />Development
          <br />Communication
        </div>

        <div className="services-gallery-wrapper">
          {
            DEMO_LIST.map(({ img }, index) => (
              <div key={index} className="services-item">
                <MyImg className="img" src={img} />
                <div className='mask'></div>
              </div>
            ))
          }
        </div>
      </div >
    )
  } else {
    return (
      <div
        className="section services-section"
        ref={sectionRef}
      >
        <div
          className="section-fixed-content"
          ref={sectionFixedContentRef}>
          <div className="section-title">OUR DESIGNS</div>
        </div>

        <div className="services-gallery-wrapper">
          <div className="services-gallery-stage">
            <div className="services-gallery">
              <Gallery2
                height={300}
                start={galleryStart}
                onChange={(curEl, preEl) => {
                  curEl.classList.add('active');
                  if (preEl) preEl.classList.remove('active');
                }}
              >
                {
                  DEMO_LIST.map(({ img }, index) => (
                    <div key={index} className="services-item">
                      <MyImg className="img" src={img} />
                      <div className='mask'></div>
                    </div>
                  ))
                }
              </Gallery2>
            </div>
          </div>

          <div className="services-desc">
            UX Strategy
            <br />UI Design
            <br />Development
            <br />Communication
          </div>
        </div>
      </div>
    )
  }
}