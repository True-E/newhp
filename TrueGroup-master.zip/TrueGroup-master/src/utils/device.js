// 是否是手机，pad 按 pc 展示
export const isMobile = /Android|iPhone|SymbianOS|Windows Phone/i.test(navigator.userAgent);