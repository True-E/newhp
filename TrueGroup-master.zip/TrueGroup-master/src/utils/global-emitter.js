const eventListeners = {};
let listenerId = 0;

export function emit(event, ...args) {
  if (!eventListeners[event]) return;
  eventListeners[event].forEach((listener) => {
    listener.callback.apply(this, args);
  })
}

export function on(event, callback) {
  if (!eventListeners[event]) eventListeners[event] = [];

  listenerId++;

  eventListeners[event].push({
    callback,
    listenerId
  })

  return listenerId;
}


export function off(event, listenerId) {
  if (!eventListeners[event]) return true;
  
  eventListeners[event] = eventListeners[event].filter(listener => listener.listenerId !== listenerId);

  return true;
}

export default {
  on,
  emit,
  off
}