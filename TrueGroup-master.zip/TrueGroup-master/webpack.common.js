const path = require('path');
const glob = require('glob');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

module.exports = {
  entry: getEntry(),
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: ['babel-loader']
      },
      {
        test: /\.css$/i,
        exclude: /node_modules/,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'postcss-loader'],
      },
      {
        test: /\.s[ac]ss$/i,
        exclude: /node_modules/,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'postcss-loader', 'sass-loader'],
      },
      {
        test: /\.(png|svg|jpg|jpeg|gif)$/i,
        exclude: /node_modules/,
        type: 'asset/resource',
      },
      {
        test: /\.(woff|woff2|eot|ttf|otf)$/i,
        exclude: /node_modules/,
        type: 'asset/resource',
      },
      {
        test: /\.mp4$/,
        use: 'file-loader?name=[hash].[ext]',
      }
    ],
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: "[name]/index.css"
    }),
    ...getHtmlTemplate()
  ],
  resolve: {
    extensions: ['*', '.js', '.jsx']
  },
  output: {
    filename: '[name]/index.bundle.js',
    path: path.resolve(__dirname, 'dist'),
    clean: true,
  },
};

// 多页入口
function getEntry() {
  return glob.sync('./src/pages/**/index.jsx').reduce((pre, file) => {
    const name = file.match(/\/pages\/(.+)\/index.js/)[1];
    pre[name] = file;
    return pre;
  }, {});
}

// 多页模板
function getHtmlTemplate() {
  return glob
    .sync('./src/pages/**/index.html')
    .map((file) => {
      return { name: file.match(/\/pages\/(.+)\/index.html/)[1], path: file };
    })
    .map(
      (template) =>
        new HtmlWebpackPlugin({
          minify: false,
          inject: 'body',
          template: template.path,
          chunks: [template.name.toString()],
          filename: `${template.name}/index.html`,
        })
    );
}